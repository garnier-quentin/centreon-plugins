#!/usr/bin/perl

use warnings;
use strict;

centreon::script::centreon_centengine_retention->new()->run();

package centreon::script::centreon_centengine_retention;

use strict;
use warnings;
use centreon::script;
use centreon::common::misc;
use Data::Dumper;
use JSON::XS;

use FindBin;
use lib "$FindBin::Bin";

use base qw(centreon::script);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(
        'centreon_centengine_retention',
        centreon_db_conn => 0,
        centstorage_db_conn => 0,
        noconfig => 0
    );

    $self->add_options(
        'retention-file:s' => \$self->{retention_file},
        'mapping-file:s'   => \$self->{mapping_file}
    );

    bless $self, $class;
    return $self;
}

sub slurp_file {
    my ($self, %options) = @_;

    my $content = do {
        local $/ = undef;
        if (!open my $fh, '<', $options{file}) {
            $self->{logger}->writeLogError("could not open file $options{file}: $!");
            exit(1);
        }
        <$fh>;
    };

    return $content;
}

sub init {
    my $self = shift;
    $self->SUPER::init();

    $self->{mapping_file} = 'mapping_hosts_services.json' if (!defined($self->{mapping_file}) || $self->{mapping_file} eq '');

    my $content = $self->slurp_file(file => $self->{mapping_file});
    eval {
        $self->{mapping} = JSON::XS->new->utf8->decode($content);
    };
    if ($@) {
        $self->{logger}->writeLogError("cannot decode json: $@");
        exit(1);
    }

    if (!defined($self->{retention_file}) || $self->{retention_file} eq '') {
        $self->{logger}->writeLogError("please define --retention-file option");
        exit(1);
    }

    $self->{retention_src} = $self->slurp_file(file => $self->{retention_file});
    $self->{retention_target} = '';
}

sub run {
    my $self = shift;

    $self->SUPER::run();

    my $nfilename = $self->{retention_file} . '.new';
    my $fh;
    if (!open($fh, '>', $nfilename)) {
        $self->{logger}->writeLogError("cannot write file '$nfilename': $!");
        exit(1);
    }

    while ($self->{retention_src} =~ /^\s*([^{]+?)\s*({.*?\n})/msig) {
        my ($objectName, $content) = ($1, $2);
        
        # objectName: host, service (no IDs in comment and downtime objects)
        if ($objectName eq 'host') {
            if ($content =~ /^host_id=(\d+)\s*/ms) {
                my $srcHostId = $1;
                if (defined($self->{mapping}->{hosts}->{$srcHostId})) {
                    my $targetHostId = $self->{mapping}->{hosts}->{$srcHostId};
                    $content =~ s/^host_id=[0-9]+/host_id=$targetHostId/ms;
                }
            }
        }
 
        if ($objectName eq 'service') {
            my ($srcHostId, $srcServiceId);
            $srcHostId = $1 if ($content =~ /^host_id=(\d+)\s*/ms);
            $srcServiceId = $1 if ($content =~ /^service_id=(\d+)\s*/ms);
            
            if (defined($srcServiceId) && defined($self->{mapping}->{hosts_services}->{ "$srcHostId-$srcServiceId" })) {
                my ($targetHostId, $targetServiceId) = split(/-/, $self->{mapping}->{hosts_services}->{ "$srcHostId-$srcServiceId" });
                $content =~ s/^host_id=[0-9]+/host_id=$targetHostId/ms;
                $content =~ s/^service_id=[0-9]+/service_id=$targetServiceId/ms;
            }
        }
 
        print $fh "$objectName $content\n";
    }

    close $fh;
}

__END__

=head1 NAME

centreon_centengine_retention.pl - a script to change retention.dat IDs

=head1 SYNOPSIS

centreon_centengine_retention.pl [options]

=head1 OPTIONS

=over 8

=item B<--config>

Define path to the main configuration file (default: /etc/centreon/conf.pm).

=item B<--logfile>

Write log messages into this file instead of the standard output.

=item B<--help>

Print a brief help message and exits.

=item B<--retention-file>

Define retention file to change.

=item B<--mapping-file>

Define mapping file used to change IDs.

=back

=head1 DESCRIPTION

B<centreon_centengine_retention> will read retention.dat file.

=cut
