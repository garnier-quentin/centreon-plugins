#!/usr/bin/perl

use warnings;
use strict;

centreon::script::centreon_install_pp->new()->run();

package centreon::script::centreon_install_pp;

use strict;
use warnings;
use centreon::script;
use centreon::common::misc;
use Data::Dumper;

use FindBin;
use lib "$FindBin::Bin";

use gorgone::class::http::http;
use JSON::XS;

use base qw(centreon::script);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(
        'centreon_install_pp',
        centreon_db_conn => 0,
        centstorage_db_conn => 0,
        noconfig => 0
    );

    $self->add_options(
#        'clapi-username:s' => \$self->{clapi_username}
    );

    bless $self, $class;
    return $self;
}

sub init {
    my $self = shift;
    $self->SUPER::init();

    $self->{http} = gorgone::class::http::http->new(logger => $self->{logger});

    $self->{curl_opts} = [
        'CURLOPT_SSL_VERIFYPEER => 0',
        'CURLOPT_SSL_VERIFYHOST => 0',
        'CURLOPT_POSTREDIR => CURL_REDIR_POST_ALL'
    ];

    my ($code, $content) = $self->{http}->request(
        http_backend => 'curl',
        method => 'POST',
        hostname => '',
        full_url => 'https://10.111.13.97/centreon/api/index.php',
        post_param => [
            'username=qgarnier',
            'password=Centreon2026!'
        ],
        get_param => [
            'action=authenticate'
        ],
        curl_opt => $self->{curl_opts},
        warning_status => '',
        unknown_status => '',
        critical_status => ''
    );
    if ($code) {
        $self->{logger}->writeLogError('http request error');
        exit(1);
    }
    if ($self->{http}->get_code() < 200 || $self->{http}->get_code() >= 300) {
        $self->{logger}->writeLogError("Login error [code: '" . $self->{http}->get_code() . "'] [message: '" . $self->{http}->get_message() . "']");
        exit(1);
    }

    my $decoded;
    eval {
        $decoded = JSON::XS->new->decode($content);
    };
    if ($@) {
        $self->{logger}->writeLogError("cannot decode json response: $@");
        exit(1);
    }

    my $token = defined($decoded->{authToken}) ? $decoded->{authToken} : undef;
    if (!defined($token)) {
        $self->{logger}->writeLogError('cannot get token');
        exit(1);
    }

    $self->{token} = $token;
}

sub add_centreon_pp {
    my ($self, %options) = @_;

    my $npp = {
        pluginpack => [
            { slug => 'applications-active-directory-wsman', version => '26.03.0', action => 'install' },
            { slug => 'applications-ansible-cli', version => '26.03.0', action => 'install' },
            { slug => 'applications-monitoring-iplabel-newtest-restapi', version => '26.03.0', action => 'install' },
            { slug => 'applications-protocol-ntp', version => '26.03.0', action => 'install' },
            { slug => 'applications-protocol-smtp', version => '26.03.0', action => 'install' },
            { slug => 'applications-wallix-bastion-snmp', version => '26.03.0', action => 'install' },
            { slug => 'applications-wsus-nsclient', version => '26.06.0', action => 'install' },
            { slug => 'cloud-kubernetes-api', version => '26.09.0', action => 'install' },
            { slug => 'hardware-pdu-raritan-snmp', version => '26.03.0', action => 'install' },
            { slug => 'hardware-servers-dell-openmanage-snmp', version => '26.03.0', action => 'install' },
            { slug => 'infrastructure-active-directory-nrpe', version => '26.03.0', action => 'install' },
            { slug => 'network-atto-fibrebridge-snmp', version => '26.03.0', action => 'install' },
            { slug => 'network-dell-os10-snmp', version => '26.03.0', action => 'install' },
            { slug => 'network-dell-sseries-snmp', version => '26.03.0', action => 'install' },
            { slug => 'network-fortinet-fortiauthenticator-snmp', version => '26.03.0', action => 'install' },
            { slug => 'network-stormshield-snmp', version => '26.08.4', action => 'install' },
            { slug => 'network-stormshield-ssh', version => '26.03.0', action => 'install' },
            { slug => 'network-switchs-cisco-smallbusiness-standard-snmp', version => '26.07.1', action => 'install' },
            { slug => 'operatingsystems-linux-nrpe3', version => '25.10.0', action => 'install' },
            { slug => 'operatingsystems-windows-wsman', version => '26.07.1', action => 'install' },
            { slug => 'virtualization-hyperv-2012-nrpe', version => '26.06.0', action => 'install' },
        ]
    };

    my $json_encode;
    eval {
        $json_encode = encode_json($npp);
    };
    if ($@) {
        $self->{logger}->writeLogError("host '" . $options{host}->{name} . "' cannot json encode: $@");
        return ;
    }

    my ($code, $content) = $self->{http}->request(
        http_backend => 'curl',
        method => 'POST',
        hostname => '',
        full_url => 'https://10.111.13.97/centreon/api/index.php',
        query_form_post => $json_encode,
        get_param => [
            'object=centreon_pp_manager_pluginpack',
            'action=installupdate'
        ],
        header => [
            'Accept-Type: application/json; charset=utf-8',
            'Content-Type: application/json; charset=utf-8',
            'centreon-auth-token: ' . $self->{token}
        ],
        curl_opt => $self->{curl_opts},
        warning_status => '',
        unknown_status => '',
        critical_status => ''
    );
}

sub run {
    my $self = shift;

    $self->SUPER::run();

    $self->add_centreon_pp();
}

__END__

=head1 NAME

centreon_install_pp.pl - a script to install a centreon monitoring connector

=head1 SYNOPSIS

centreon_install_pp.pl [options]

=head1 OPTIONS

=over 8

=item B<--config>

Specify the path to the main configuration file (default: /etc/centreon/conf.pm).

=item B<--logfile>

Write log messages into this file instead of the standard output.

=item B<--help>

Print a brief help message and exits.

=back

=head1 DESCRIPTION

B<centreon_install_pp> will use centreon API.

=cut
