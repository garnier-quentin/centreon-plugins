#!/usr/bin/perl

use warnings;
use strict;

centreon::script::centreon_rrds->new()->run();

package centreon::script::centreon_rrds;

use strict;
use warnings;
use centreon::script;
use centreon::common::misc;
use Data::Dumper;
use JSON::XS;
use File::Copy;
use POSIX;

use FindBin;
use lib "$FindBin::Bin";

use base qw(centreon::script);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(
        'centreon_rrds',
        centreon_db_conn => 0,
        centstorage_db_conn => 0,
        noconfig => 0
    );

    $self->add_options(
        'status-directory-src:s'     => \$self->{status_directory_src},
        'status-directory-target:s'  => \$self->{status_directory_target},
        'metrics-directory-src:s'    => \$self->{metrics_directory_src},
        'metrics-directory-target:s' => \$self->{metrics_directory_target},
        'mapping-file:s'   => \$self->{mapping_file}
    );

    bless $self, $class;
    return $self;
}

sub slurp_file {
    my ($self, %options) = @_;

    my $content = do {
        local $/ = undef;
        if (!open my $fh, '<', $options{file}) {
            $self->{logger}->writeLogError("could not open file $options{file}: $!");
            exit(1);
        }
        <$fh>;
    };

    return $content;
}

sub init {
    my $self = shift;
    $self->SUPER::init();

    $self->{mapping_file} = 'mapping_metrics.json' if (!defined($self->{mapping_file}) || $self->{mapping_file} eq '');

    my $content = $self->slurp_file(file => $self->{mapping_file});
    eval {
        $self->{mapping} = JSON::XS->new->utf8->decode($content);
    };
    if ($@) {
        $self->{logger}->writeLogError("cannot decode json: $@");
        exit(1);
    }

    $self->{status_directory_target} = '/var/lib/centreon/status' if (!defined($self->{status_directory_target}) || $self->{status_directory_target} eq '');
    $self->{metrics_directory_target} = '/var/lib/centreon/metrics' if (!defined($self->{metrics_directory_target}) || $self->{metrics_directory_target} eq '');

    my ($login, $pass, $uid, $gid) = POSIX::getpwnam('centreon-broker');
    $self->{uid} = $uid;
    $self->{gid} = $gid;
}

sub moveRrdFiles {
    my ($self, %options) = @_;

    return if (!defined($options{dir_src}) || $options{dir_src} eq '');

    $self->{logger}->writeLogInfo("move " . $options{mapping_attr} . " from '" . $options{dir_src} . "' --> '" . $options{dir_target} . "'");

    my $dh;
    if (!opendir($dh, $options{dir_src})) {
        $self->{logger}->writeLogError("cannot open directory '$options{dir_src}': $!");
        exit(1);
    }

    my $numFiles = 0;
    while (my $file = readdir($dh)) {
        next if ($file !~ /([0-9]+)\.rrd/);
        my $srcId = $1;

        next if (!defined($self->{mapping}->{ $options{mapping_attr} }->{$srcId}));
        
        if (File::Copy::move($options{dir_src} . '/' . $file, $options{dir_target} . '/' . $self->{mapping}->{ $options{mapping_attr} }->{$srcId} . '.rrd')) {
            chown($self->{uid}, $self->{gid}, $options{dir_target} . '/' .$self->{mapping}->{ $options{mapping_attr} }->{$srcId} . '.rrd');
            chmod(0664, $options{dir_target} . '/' . $self->{mapping}->{ $options{mapping_attr} }->{$srcId} . '.rrd');
            $numFiles++;
        } else {
            $self->{logger}->writeLogError("cannot move file '$options{dir_src}/$file': $!");
        }
    }

    closedir($dh);

    $self->{logger}->writeLogInfo("number of files moved: $numFiles");
}

sub run {
    my $self = shift;

    $self->SUPER::run();

    $self->moveRrdFiles(
        dir_src => $self->{status_directory_src},
        dir_target => $self->{status_directory_target},
        mapping_attr => 'rrd_status'
    );
    $self->moveRrdFiles(
        dir_src => $self->{metrics_directory_src},
        dir_target => $self->{metrics_directory_target},
        mapping_attr => 'rrd_metrics'
    );
}

__END__

=head1 NAME

centreon_rrds.pl - a script to change RRD files IDs

=head1 SYNOPSIS

centreon_rrds.pl [options]

=head1 OPTIONS

=over 8

=item B<--config>

Define path to the main configuration file (default: /etc/centreon/conf.pm).

=item B<--logfile>

Write log messages into this file instead of the standard output.

=item B<--help>

Print a brief help message and exits.

=item B<--status-directory-src>

Define status directory with old rrd files IDs.

=item B<--status-directory-target>

Define status directory for new files.

=item B<--metrics-directory-src>

Define metrics directory with old rrd files IDs.

=item B<--metrics-directory-target>

Define metrics directory for new files.

=item B<--mapping-file>

Define mapping file used to change IDs.

=back

=head1 DESCRIPTION

B<centreon_rrds> will read source directories.

=cut
