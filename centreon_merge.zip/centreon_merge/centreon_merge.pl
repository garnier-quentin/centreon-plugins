#!/usr/bin/perl

use warnings;
use strict;

centreon::script::centreon_merge->new()->run();

package centreon::script::centreon_merge;

use strict;
use warnings;
use centreon::script;
use centreon::common::misc;
use Data::Dumper;

use FindBin;
use lib "$FindBin::Bin";

use objects::aclAction;
use objects::aclGroup;
use objects::aclMenu;
use objects::aclResource;
use objects::bamBa;
use objects::bamBaGroups;
use objects::bamBoolean;
use objects::bamKpi;
use objects::command;
use objects::connector;
use objects::contact;
use objects::contactGroup;
use objects::contactTpl;
use objects::downtime;
use objects::host;
use objects::hostCategory;
use objects::hostGroup;
use objects::ldap;
use objects::media;
use objects::service;
use objects::serviceCategory;
use objects::serviceGroup;
use objects::serviceTpl;
use objects::timeperiod;

use objects::centstorage::bamEvents;
use objects::centstorage::comments;
use objects::centstorage::downtimes;
use objects::centstorage::logAction;
use objects::centstorage::logArchiveHost;
use objects::centstorage::logArchiveService;
use objects::centstorage::logs;
use objects::centstorage::hostStateEvents;
use objects::centstorage::metrics;
use objects::centstorage::realtimeLegacy;
use objects::centstorage::serviceStateEvents;

use base qw(centreon::script);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(
        'centreon_merge',
        centreon_db_conn => 0,
        centstorage_db_conn => 0,
        noconfig => 0
    );

    $self->add_options(
#        'clapi-username:s' => \$self->{clapi_username}
    );

    bless $self, $class;
    return $self;
}

sub init {
    my $self = shift;
    $self->SUPER::init();

    $self->{db} = { src => {} , target => {} };
    $self->{db}->{src}->{centreon} = centreon::common::db->new(
        db => 'centreon',
        host => '192.168.1.21',
        port => 3306,
        user => 'centreon_migrate',
        password => 'centreon',
        force => 0,
        logger => $self->{logger}
    );
    $self->{db}->{src}->{centreon}->connect();

    $self->{db}->{target}->{centreon} = centreon::common::db->new(
        db => 'centreon',
        host => '192.168.1.20',
        port => 3306,
        user => 'centreon_migrate',
        password => 'centreon',
        force => 0,
        logger => $self->{logger}
    );
    $self->{db}->{target}->{centreon}->connect();

    $self->{aclAction} = objects::aclAction->new(logger => $self->{logger}, db => $self->{db});
    $self->{aclGroup} = objects::aclGroup->new(logger => $self->{logger}, db => $self->{db});
    $self->{aclMenu} = objects::aclMenu->new(logger => $self->{logger}, db => $self->{db});
    $self->{aclResource} = objects::aclResource->new(logger => $self->{logger}, db => $self->{db});
    $self->{bamBa} = objects::bamBa->new(logger => $self->{logger}, db => $self->{db});
    $self->{bamBaGroups} = objects::bamBaGroups->new(logger => $self->{logger}, db => $self->{db});
    $self->{bamBoolean} = objects::bamBoolean->new(logger => $self->{logger}, db => $self->{db});
    $self->{bamKpi} = objects::bamKpi->new(logger => $self->{logger}, db => $self->{db});
    $self->{downtime} = objects::downtime->new(logger => $self->{logger}, db => $self->{db});
    $self->{media} = objects::media->new(logger => $self->{logger}, db => $self->{db});
    $self->{timeperiod} = objects::timeperiod->new(logger => $self->{logger}, db => $self->{db});
    $self->{contactTpl} = objects::contactTpl->new(logger => $self->{logger}, db => $self->{db});
    $self->{command} = objects::command->new(logger => $self->{logger}, db => $self->{db});
    $self->{connector} = objects::connector->new(logger => $self->{logger}, db => $self->{db});
    $self->{ldap} = objects::ldap->new(logger => $self->{logger}, db => $self->{db});
    $self->{contact} = objects::contact->new(logger => $self->{logger}, db => $self->{db});
    $self->{contactGroup} = objects::contactGroup->new(logger => $self->{logger}, db => $self->{db});
    $self->{host} = objects::host->new(logger => $self->{logger}, db => $self->{db});
    $self->{hostCategory} = objects::hostCategory->new(logger => $self->{logger}, db => $self->{db});
    $self->{hostGroup} = objects::hostGroup->new(logger => $self->{logger}, db => $self->{db});
    $self->{service} = objects::service->new(logger => $self->{logger}, db => $self->{db});
    $self->{serviceCategory} = objects::serviceCategory->new(logger => $self->{logger}, db => $self->{db});
    $self->{serviceGroup} = objects::serviceGroup->new(logger => $self->{logger}, db => $self->{db});
    $self->{serviceTpl} = objects::serviceTpl->new(logger => $self->{logger}, db => $self->{db});
}

sub init_centstorage {
    my $self = shift;

    $self->{metrics_filename} = 'mapping_metrics.json';
    $self->{hs_filename} = 'mapping_hosts_services.json';

    $self->{db}->{src}->{centstorage} = centreon::common::db->new(
        db => 'centreon_storage',
        host => '192.168.1.21',
        port => 3306,
        user => 'centreon_migrate',
        password => 'centreon',
        force => 0,
        logger => $self->{logger}
    );
    $self->{db}->{src}->{centstorage}->connect();

    $self->{db}->{target}->{centstorage} = centreon::common::db->new(
        db => 'centreon_storage',
        host => '192.168.1.20',
        port => 3306,
        user => 'centreon_migrate',
        password => 'centreon',
        force => 0,
        logger => $self->{logger}
    );
    $self->{db}->{target}->{centreon}->connect();
    
    $self->{logs} = objects::centstorage::logs->new(logger => $self->{logger}, db => $self->{db});
    $self->{hostStateEvents} = objects::centstorage::hostStateEvents->new(logger => $self->{logger}, db => $self->{db});
    $self->{serviceStateEvents} = objects::centstorage::serviceStateEvents->new(logger => $self->{logger}, db => $self->{db});
    $self->{logArchiveHost} = objects::centstorage::logArchiveHost->new(logger => $self->{logger}, db => $self->{db});
    $self->{logArchiveService} = objects::centstorage::logArchiveService->new(logger => $self->{logger}, db => $self->{db});
    $self->{logAction} = objects::centstorage::logAction->new(logger => $self->{logger}, db => $self->{db});
    $self->{bamEvents} = objects::centstorage::bamEvents->new(logger => $self->{logger}, db => $self->{db});
    $self->{metrics} = objects::centstorage::metrics->new(logger => $self->{logger}, db => $self->{db}, metrics_filename => $self->{metrics_filename});
    $self->{realtimeLegacy} = objects::centstorage::realtimeLegacy->new(logger => $self->{logger}, db => $self->{db}, metrics_filename => $self->{metrics_filename});
    $self->{comments} = objects::centstorage::comments->new(logger => $self->{logger}, db => $self->{db}, metrics_filename => $self->{metrics_filename});
    $self->{dt} = objects::centstorage::downtimes->new(logger => $self->{logger}, db => $self->{db}, metrics_filename => $self->{metrics_filename});
}

sub run {
    my $self = shift;

    $self->SUPER::run();

    $self->{media}->merge();
    $self->{timeperiod}->merge();
    $self->{connector}->merge();
    $self->{command}->merge(connector => $self->{connector});
    $self->{contactTpl}->merge(timeperiod => $self->{timeperiod}, command => $self->{command});
    $self->{ldap}->merge(contactTpl => $self->{contactTpl});
    $self->{contact}->merge(timeperiod => $self->{timeperiod}, command => $self->{command}, ldap => $self->{ldap}, contactTpl => $self->{contactTpl});
    $self->{contactGroup}->merge(contact => $self->{contact});
    $self->{serviceTpl}->merge(
        timeperiod => $self->{timeperiod},
        command => $self->{command},
        contact => $self->{contact},
        contactGroup => $self->{contactGroup},
        media => $self->{media}
    );
    $self->{host}->merge(
        timeperiod => $self->{timeperiod},
        command => $self->{command},
        contact => $self->{contact},
        contactGroup => $self->{contactGroup},
        media => $self->{media},
        serviceTpl => $self->{serviceTpl}
    );
    $self->{hostGroup}->merge(host => $self->{host}, media => $self->{media});
    $self->{hostCategory}->merge(host => $self->{host}, media => $self->{media});

    $self->{service}->merge(
        host => $self->{host},
        timeperiod => $self->{timeperiod},
        command => $self->{command},
        contact => $self->{contact},
        contactGroup => $self->{contactGroup},
        media => $self->{media},
        serviceTpl => $self->{serviceTpl}
    );

    $self->{serviceGroup}->merge(host => $self->{host}, service => $self->{service}, serviceTpl => $self->{serviceTpl});
    $self->{serviceCategory}->merge(host => $self->{host}, service => $self->{service}, serviceTpl => $self->{serviceTpl}, media => $self->{media});

    $self->{aclAction}->merge();
    $self->{aclMenu}->merge();
    $self->{aclResource}->merge(
        hostCategory => $self->{hostCategory},
        hostGroup => $self->{hostGroup},
        host => $self->{host},
        serviceGroup => $self->{serviceGroup},
        serviceCategory => $self->{serviceCategory},
        service => $self->{service}
    );
    $self->{aclGroup}->merge(
        contact => $self->{contact},
        contactGroup => $self->{contactGroup},
        aclAction => $self->{aclAction},
        aclMenu => $self->{aclMenu},
        aclResource => $self->{aclResource}
    );

    $self->{downtime}->merge(
        hostGroup => $self->{hostGroup},
        host => $self->{host},
        serviceGroup => $self->{serviceGroup},
        service => $self->{service}
    );

    $self->{bamBoolean}->merge();
    $self->{bamBaGroups}->merge(aclGroup => $self->{aclGroup});
    $self->{bamBa}->merge(
        bamBaGroups => $self->{bamBaGroups},
        timeperiod => $self->{timeperiod},
        media => $self->{media},
        command => $self->{command},
        contactGroup => $self->{contactGroup},
        host => $self->{host},
        service => $self->{service}
    );
    $self->{bamKpi}->merge(
        bamBoolean => $self->{bamBoolean},
        bamBa => $self->{bamBa},
        service => $self->{service}
    );

    $self->init_centstorage();
    $self->{logs}->merge(
        host => $self->{host},
        service => $self->{service}
    );
    $self->{hostStateEvents}->merge(host => $self->{host});
    $self->{serviceStateEvents}->merge(service => $self->{service});
    $self->{logArchiveHost}->merge(host => $self->{host});
    $self->{logArchiveService}->merge(service => $self->{service});
    $self->{logAction}->merge(
        aclAction => $self->{aclAction},
        aclMenu => $self->{aclMenu},
        aclResource => $self->{aclResource},
        aclGroup => $self->{aclGroup},
        contact => $self->{contact},
        contactTpl => $self->{contactTpl},
        host => $self->{host},
        service => $self->{service},
        serviceTpl => $self->{serviceTpl},
        serviceCategory => $self->{serviceCategory},
        serviceGroup => $self->{serviceGroup},
        hostCategory => $self->{hostCategory},
        hostGroup => $self->{hostGroup},
        contactGroup => $self->{contactGroup},
        command => $self->{command},
        timeperiod => $self->{timeperiod}
    );
    $self->{bamEvents}->merge(
        bamBaGroups => $self->{bamBaGroups},
        bamBa => $self->{bamBa},
        bamKpi => $self->{bamKpi},
        timeperiod => $self->{timeperiod},
        bamBoolean => $self->{bamBoolean},
        service => $self->{service}
    );
    $self->{metrics}->merge(service => $self->{service});

    $self->{realtimeLegacy}->merge(
        host => $self->{host},
        service => $self->{service}
    );
    $self->{comments}->merge(
        host => $self->{host},
        service => $self->{service}
    );
    $self->{dt}->merge(
        host => $self->{host},
        service => $self->{service}
    );

    $self->{metrics}->writeFile(
        value => {
            hosts => $self->{host}->getMappingHosts(),
            hosts_services => $self->{service}->getMappingHostServices()
        }, 
        filename => $self->{hs_filename}
    );
}

__END__

=head1 NAME

centreon_merge.pl - a script to merge Centreon instances

=head1 SYNOPSIS

centreon_merge.pl [options]

=head1 OPTIONS

=over 8

=item B<--config>

Specify the path to the main configuration file (default: /etc/centreon/conf.pm).

=item B<--logfile>

Write log messages into this file instead of the standard output.

=item B<--help>

Print a brief help message and exits.

=back

=head1 DESCRIPTION

B<centreon_merge> will read centreon databases.

=cut
