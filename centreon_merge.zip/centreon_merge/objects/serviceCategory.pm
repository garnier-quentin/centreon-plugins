#!/usr/bin/perl

package objects::serviceCategory;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'service_categories',
        attr_id => 'sc_id',
        attr_name => 'sc_name',
        store => 'servicecategories',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service_categories',
        attr_id => 'sc_id',
        attr_name => 'sc_name',
        store => 'servicecategories'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'service_categories_relation',
        attr_id_key => 'sc_id',
        attr_id_value => 'service_service_id',
        store => 'scRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service_categories_relation',
        attr_id_key => 'sc_id',
        attr_id_value => 'service_service_id',
        store => 'scRelation',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{servicecategories}->{byID}->{ $options{srcId} }->{sc_name};
    return $self->{load}->{target}->{servicecategories}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{servicecategories}->{byID}->{ $options{srcId} }->{sc_name};
}

sub addServiceTplRelation {
    my ($self, %options) = @_;

    my $displayServiceName = $options{serviceTpl}->getNameFromSrcId(srcId => $options{srcServiceId});
                
    my $isAssigned = 0;
    foreach (@{$self->{load}->{target}->{scRelation}->{ $options{scTargetId} }}) {
        if ($_ == $options{serviceId}) {
            $isAssigned = 1;
            last;
        }
    }

    if ($isAssigned == 1) {
        $self->{logger}->writeLogDebug("service category '" . $options{scName} . "': service template '$displayServiceName' already linked");
        return ;
    }

    $self->insertTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service_categories_relation',
        name => $options{scName} . "-$displayServiceName",
        entry => {
            sc_id => $options{scTargetId},
            service_service_id => $options{serviceId}
        }
    );

    $self->{logger}->writeLogDebug("service category '" . $options{scName} . "': service template '$displayServiceName' linked");
}

sub addServiceRelation {
    my ($self, %options) = @_;

    my $relations = $options{host}->getSrcHostServicesRelation();
    foreach my $srcHostId (keys %$relations) {
        foreach my $srcServiceId (@{$relations->{$srcHostId}}) {
            next if ($srcServiceId != $options{srcServiceId});

            my ($hostId, $serviceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $srcHostId, srcServiceId => $srcServiceId);
            my $displayHostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);
            my $displayServiceName = $options{service}->getNameFromSrcId(srcId => $srcServiceId);

            my $isAssigned = 0;
            foreach (@{$self->{load}->{target}->{scRelation}->{ $options{scTargetId} }}) {
                if ($_ == $serviceId) {
                    $isAssigned = 1;
                    last;
                }
            }

            if ($isAssigned == 1) {
                $self->{logger}->writeLogDebug("service category '" . $options{scName} . "': service '$displayHostName - $displayServiceName' already linked");
                return ;
            }

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'service_categories_relation',
                name => $options{scName} . "-$displayHostName-$displayServiceName",
                entry => {
                    sc_id => $options{scTargetId},
                    service_service_id => $serviceId
                }
            );

            $self->{logger}->writeLogDebug("service category '" . $options{scName} . "': service '$displayHostName - $displayServiceName' linked");
        }
    }
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{servicecategories}->{byID}}) {
        my $name = $self->{load}->{src}->{servicecategories}->{byID}->{$srcId}->{sc_name};

        my ($targetId, $entry); 
        if (defined($self->{load}->{target}->{servicecategories}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("service category '" . $name . "' already exists");
            $targetId = $self->{load}->{target}->{servicecategories}->{byName}->{$name};
        } else {
            my $copy = $self->{load}->{src}->{servicecategories}->{byID}->{$srcId};
            $copy->{icon_id} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{servicecategories}->{byID}->{$srcId}->{icon_id});

            ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'service_categories',
                name => $name,
                entry => $copy,
                exclude => {
                    sc_id => 1
                }
            );

            $self->{load}->{target}->{servicecategories}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{servicecategories}->{byID}->{$targetId} = $entry;

            $self->{logger}->writeLogInfo("service category '" . $name . "' created");
        }

        foreach my $srcServiceId (@{$self->{load}->{src}->{scRelation}->{$srcId}}) {
            my $displayServiceName;
            my $serviceId = $options{serviceTpl}->getTargetIdFromSrcId(srcId => $srcServiceId);
            if (defined($serviceId)) {
                $self->addServiceTplRelation(scTargetId => $targetId, scName => $name, serviceId => $serviceId, srcServiceId => $srcServiceId, %options);
            }

            $self->addServiceRelation(scTargetId => $targetId, scName => $name, srcServiceId => $srcServiceId, %options);
        }
    }
}

1;

__END__