#!/usr/bin/perl

package objects::connector;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'connector',
        attr_id => 'id',
        attr_name => 'name',
        store => 'connector',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'connector',
        attr_id => 'id',
        attr_name => 'name',
        store => 'connector'
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    my $srcName = $self->{load}->{src}->{connector}->{byID}->{ $options{srcId} }->{name};
    return $self->{load}->{target}->{connector}->{byName}->{$srcName};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{connector}->{byID}}) {
        my $name = $self->{load}->{src}->{connector}->{byID}->{$srcId}->{name};
        if (defined($self->{load}->{target}->{connector}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("connector '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'connector',
            name => $name,
            entry => $self->{load}->{src}->{connector}->{byID}->{$srcId},
            exclude => {
                id => 1
            }
        );

        $self->{load}->{target}->{connector}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{connector}->{byID}->{$targetId} = $entry;

        $self->{logger}->writeLogInfo("connector '" . $name . "' created");
    }
}

1;

__END__