#!/usr/bin/perl

package objects::aclAction;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_actions',
        attr_id => 'acl_action_id',
        attr_name => 'acl_action_name',
        store => 'aclActions',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_actions',
        attr_id => 'acl_action_id',
        attr_name => 'acl_action_name',
        store => 'aclActions'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_actions_rules',
        attr_id_key => 'acl_action_rule_id',
        store => 'aclActionsRules',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_actions_rules',
        attr_id_key => 'acl_action_rule_id',
        store => 'aclActionsRules',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    my $srcName = $self->{load}->{src}->{aclActions}->{byID}->{ $options{srcId} }->{acl_action_name};
    return $self->{load}->{target}->{aclActions}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{aclActions}->{byID}->{ $options{srcId} }->{acl_action_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{aclActions}->{byID}}) {
        my $name = $self->{load}->{src}->{aclActions}->{byID}->{$srcId}->{acl_action_name};
        if (defined($self->{load}->{target}->{aclActions}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("acl action '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'acl_actions',
            name => $name,
            entry => $self->{load}->{src}->{aclActions}->{byID}->{$srcId},
            exclude => {
                acl_action_id => 1
            }
        );

        $self->{load}->{target}->{aclActions}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{aclActions}->{byID}->{$targetId} = $entry;

        # acl action rules
        foreach my $data (@{$self->{load}->{src}->{aclActionsRules}->{$srcId}}) {
            $data->{acl_action_rule_id} = $targetId;
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_actions_rules',
                name => $data->{acl_action_name},
                entry => $data,
                exclude => {
                    aar_id => 1
                }
            );
        }

        $self->{logger}->writeLogInfo("acl action '" . $name . "' created");
    }
}

1;

__END__