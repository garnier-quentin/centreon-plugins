#!/usr/bin/perl

package objects::aclResource;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources',
        attr_id => 'acl_res_id',
        attr_name => 'acl_res_name',
        store => 'aclResources',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_resources',
        attr_id => 'acl_res_id',
        attr_name => 'acl_res_name',
        store => 'aclResources'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_hc_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'hc_id',
        store => 'aclResourcesHcRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_hc_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'hc_id',
    #    store => 'aclResourcesHcRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_hg_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'hg_hg_id',
        store => 'aclResourcesHgRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_hg_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'hg_hg_id',
    #    store => 'aclResourcesHgRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_host_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'host_host_id',
        store => 'aclResourcesHostRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_host_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'host_host_id',
    #    store => 'aclResourcesHostRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_hostex_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'host_host_id',
        store => 'aclResourcesHostexRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_hostex_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'host_host_id',
    #    store => 'aclResourcesHostexRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_sg_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'sg_id',
        store => 'aclResourcesSgRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_sg_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'sg_id',
    #    store => 'aclResourcesSgRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_sc_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'sc_id',
        store => 'aclResourcesScRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_sc_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'sc_id',
    #    store => 'aclResourcesScRelations',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_resources_poller_relations',
        attr_id_key => 'acl_res_id',
        attr_id_value => 'poller_id',
        store => 'aclResourcesPollerRelations',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_resources_poller_relations',
    #    attr_id_key => 'acl_res_id',
    #    attr_id_value => 'poller_id',
    #    store => 'aclResourcesPollerRelations',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    my $srcName = $self->{load}->{src}->{aclResources}->{byID}->{ $options{srcId} }->{acl_res_name};
    return $self->{load}->{target}->{aclResources}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{aclResources}->{byID}->{ $options{srcId} }->{acl_res_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{aclResources}->{byID}}) {
        my $name = $self->{load}->{src}->{aclResources}->{byID}->{$srcId}->{acl_res_name};
        if (defined($self->{load}->{target}->{aclResources}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("acl resource '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'acl_resources',
            name => $name,
            entry => $self->{load}->{src}->{aclResources}->{byID}->{$srcId},
            exclude => {
                acl_res_id => 1,
                all_image_folders => 1 # 25.10.x
            }
        );

        $self->{load}->{target}->{aclResources}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{aclResources}->{byID}->{$targetId} = $entry;

        # host category relations
        foreach my $srcHcId (@{$self->{load}->{src}->{aclResourcesHcRelations}->{$srcId}}) {
            my $targetHcId = $options{hostCategory}->getTargetIdFromSrcId(srcId => $srcHcId);
            my $hcName = $options{hostCategory}->getNameFromSrcId(srcId => $srcHcId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_hc_relations',
                name => "$name-$hcName",
                entry => {
                    hc_id => $targetHcId,
                    acl_res_id => $targetId
                }
            );
        }

        # host group relations
        foreach my $srcHgId (@{$self->{load}->{src}->{aclResourcesHgRelations}->{$srcId}}) {
            my $targetHgId = $options{hostGroup}->getTargetIdFromSrcId(srcId => $srcHgId);
            my $hgName = $options{hostGroup}->getNameFromSrcId(srcId => $srcHgId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_hg_relations',
                name => "$name-$hgName",
                entry => {
                    hg_hg_id => $targetHgId,
                    acl_res_id => $targetId
                }
            );
        }

        # host relations
        foreach my $srcHostId (@{$self->{load}->{src}->{aclResourcesHostRelations}->{$srcId}}) {
            my $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId);
            my $hostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_host_relations',
                name => "$name-$hostName",
                entry => {
                    host_host_id => $targetHostId,
                    acl_res_id => $targetId
                }
            );
        }

        # host exclude relations
        foreach my $srcHostId (@{$self->{load}->{src}->{aclResourcesHostexRelations}->{$srcId}}) {
            my $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId);
            my $hostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_hostex_relations',
                name => "$name-$hostName",
                entry => {
                    host_host_id => $targetHostId,
                    acl_res_id => $targetId
                }
            );
        }

        # host category relations
        foreach my $srcScId (@{$self->{load}->{src}->{aclResourcesScRelations}->{$srcId}}) {
            my $targetScId = $options{serviceCategory}->getTargetIdFromSrcId(srcId => $srcScId);
            my $scName = $options{serviceCategory}->getNameFromSrcId(srcId => $srcScId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_sc_relations',
                name => "$name-$scName",
                entry => {
                    sc_id => $targetScId,
                    acl_res_id => $targetId
                }
            );
        }

        # service group relations
        foreach my $srcSgId (@{$self->{load}->{src}->{aclResourcesSgRelations}->{$srcId}}) {
            my $targetSgId = $options{serviceGroup}->getTargetIdFromSrcId(srcId => $srcSgId);
            my $sgName = $options{serviceGroup}->getNameFromSrcId(srcId => $srcSgId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_sg_relations',
                name => "$name-$sgName",
                entry => {
                    sg_id => $targetSgId,
                    acl_res_id => $targetId
                }
            );
        }

        # poller relations
        foreach my $srcPollerId (@{$self->{load}->{src}->{aclResourcesPollerRelations}->{$srcId}}) {
            my $targetPollerId = $options{host}->getTargetPollerIdFromSrcId(srcId => $srcPollerId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_resources_poller_relations',
                name => "$name-$targetPollerId",
                entry => {
                    poller_id => $targetPollerId,
                    acl_res_id => $targetId
                }
            );
        }

        # meta service unsupported

        $self->{logger}->writeLogInfo("acl resource '" . $name . "' created");
    }
}

1;

__END__