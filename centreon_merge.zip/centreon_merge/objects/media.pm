#!/usr/bin/perl

package objects::media;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'view_img_dir',
        attr_id => 'dir_id',
        attr_name => 'dir_name',
        store => 'imgDir',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'view_img_dir',
        attr_id => 'dir_id',
        attr_name => 'dir_name',
        store => 'imgDir'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'view_img_dir_relation',
        attr_id_key => 'img_img_id',
        attr_id_value => 'dir_dir_parent_id',
        store => 'imgDirRelation'
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'view_img_dir_relation',
        attr_id_key => 'img_img_id',
        attr_id_value => 'dir_dir_parent_id',
        store => 'imgDirRelation'
    );

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'view_img',
        attr_id => 'img_id',
        attr_name => 'img_name',
        store => 'img'
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'view_img',
        attr_id => 'img_id',
        attr_name => 'img_name',
        store => 'img'
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{img}->{byID}->{ $options{srcId} }->{img_name};
    return $self->{load}->{target}->{img}->{byName}->{$srcName};
}


sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{img}->{byID}}) {
        my $name = $self->{load}->{src}->{img}->{byID}->{$srcId}->{img_name};
        if (defined($self->{load}->{target}->{img}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("media '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'view_img',
            name => $name,
            entry => $self->{load}->{src}->{img}->{byID}->{$srcId},
            exclude => {
                img_id => 1
            }
        );

        $self->{load}->{target}->{img}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{img}->{byID}->{$targetId} = $entry;

        # get source imgDir name
        my $srcImgDirId = $self->{load}->{src}->{imgDirRelation}->{$srcId};
        my $imgDirName = $self->{load}->{src}->{imgDir}->{byID}->{$srcImgDirId}->{dir_name};
        
        my $targetImgDirId = $self->{load}->{target}->{imgDir}->{byName}->{$imgDirName};
        if (!defined($self->{load}->{target}->{imgDir}->{byName}->{$imgDirName})) {
            ($targetImgDirId) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'view_img_dir',
                name => $imgDirName,
                entry => $self->{load}->{src}->{imgDir}->{byID}->{$srcId},
                exclude => {
                    dir_id => 1
                }
            );
        }

        $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'view_img_dir_relation',
            name => $imgDirName,
            entry => {
                img_img_id => $targetId,
                dir_dir_parent_id => $targetImgDirId,
            }
        );
        $self->{load}->{target}->{imgDirRelation}->{$targetId} = $targetImgDirId;

        $self->{logger}->writeLogInfo("media '" . $name . "' created");
    }
}

1;

__END__