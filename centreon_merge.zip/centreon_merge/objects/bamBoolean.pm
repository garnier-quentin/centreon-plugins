#!/usr/bin/perl

package objects::bamBoolean;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_boolean',
        attr_id => 'boolean_id',
        attr_name => 'name',
        store => 'bamBoolean',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'mod_bam_boolean',
        attr_id => 'boolean_id',
        attr_name => 'name',
        store => 'bamBoolean'
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{load}->{src}->{bamBoolean}->{byID}->{ $options{srcId} }));

    my $srcName = $self->{load}->{src}->{bamBoolean}->{byID}->{ $options{srcId} }->{name};
    return $self->{load}->{target}->{bamBoolean}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{bamBoolean}->{byID}->{ $options{srcId} }->{name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{bamBoolean}->{byID}}) {
        my $name = $self->{load}->{src}->{bamBoolean}->{byID}->{$srcId}->{name};
        if (defined($self->{load}->{target}->{bamBoolean}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("bam boolean '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'mod_bam_boolean',
            name => $name,
            entry => $self->{load}->{src}->{bamBoolean}->{byID}->{$srcId},
            exclude => {
                boolean_id => 1
            }
        );

        $self->{load}->{target}->{bamBoolean}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{bamBoolean}->{byID}->{$targetId} = $entry;

        $self->{logger}->writeLogInfo("bam boolean '" . $name . "' created");
    }
}

1;

__END__