#!/usr/bin/perl

package objects::serviceGroup;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'servicegroup',
        attr_id => 'sg_id',
        attr_name => 'sg_name',
        store => 'servicegroup',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'servicegroup',
        attr_id => 'sg_id',
        attr_name => 'sg_name',
        store => 'servicegroup'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'servicegroup_relation',
        attr_id_key => 'servicegroup_sg_id',
        store => 'sgRelation',
        where => "service_service_id IS NOT NULL",
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'servicegroup_relation',
        attr_id_key => 'servicegroup_sg_id',
        store => 'sgRelation',
        where => "service_service_id IS NOT NULL",
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{servicegroup}->{byID}->{ $options{srcId} }->{sg_name};
    return $self->{load}->{target}->{servicegroup}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{servicegroup}->{byID}->{ $options{srcId} }->{sg_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{servicegroup}->{byID}}) {
        my $name = $self->{load}->{src}->{servicegroup}->{byID}->{$srcId}->{sg_name};

        my ($targetId, $entry); 
        if (defined($self->{load}->{target}->{servicegroup}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("service group '" . $name . "' already exists");
            $targetId = $self->{load}->{target}->{servicegroup}->{byName}->{$name};
        } else {
            my $copy = $self->{load}->{src}->{servicegroup}->{byID}->{$srcId};

            ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'servicegroup',
                name => $name,
                entry => $copy,
                exclude => {
                    sgr_id => 1
                }
            );

            $self->{load}->{target}->{servicegroup}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{servicegroup}->{byID}->{$targetId} = $entry;

            $self->{logger}->writeLogInfo("service group '" . $name . "' created");
        }

        foreach my $srcSgRelationEntry (@{$self->{load}->{src}->{sgRelation}->{$srcId}}) {
            my ($targetHostId, $targetServiceId);
 
            my $displayServiceName = $options{host}->getNameFromSrcId(srcId => $srcSgRelationEntry->{host_host_id}) . '-';

            ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(
                srcHostId => $srcSgRelationEntry->{host_host_id},
                srcServiceId => $srcSgRelationEntry->{service_service_id}
            );
            # can be a host template service template relation
            if (!defined($targetHostId)) {
                ($targetHostId, $targetServiceId) = $options{host}->getTargetHostServiceFromSrc(
                    srcHostId => $srcSgRelationEntry->{host_host_id},
                    srcServiceId => $srcSgRelationEntry->{service_service_id}
                );
                
                # we skipped. We only add host template relation and service relation to new host template
                next if (!defined($targetHostId));

                $displayServiceName .= $options{serviceTpl}->getNameFromSrcId(srcId => $srcSgRelationEntry->{service_service_id});
            } else {
                $displayServiceName .= $options{service}->getNameFromSrcId(srcId => $srcSgRelationEntry->{service_service_id});
            }

            my $isAssigned = 0;
            foreach (@{$self->{load}->{target}->{sgRelation}->{$targetId}}) {
                if ($_->{host_host_id} == $targetHostId && $_->{service_service_id} == $targetServiceId) {
                    $isAssigned = 1;
                    last;
                }
            }

            if ($isAssigned == 1) {
                $self->{logger}->writeLogDebug("service group '" . $name . "': service '$displayServiceName' already linked");
                next;
            }

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'servicegroup_relation',
                name => "$name-$displayServiceName",
                entry => {
                    servicegroup_sg_id => $targetId,
                    host_host_id => $targetHostId,
                    service_service_id => $targetServiceId
                }
            );

            $self->{logger}->writeLogDebug("service group '" . $name . "': service '$displayServiceName' linked");
        }
    }
}

1;

__END__