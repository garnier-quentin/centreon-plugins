#!/usr/bin/perl

package objects::service;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{mappingHostServiceIds} = {};

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        store => 'service',
        where => "service_register = '1'",
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        where => "service_register = '1'",
        store => 'service'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'extended_service_information',
        attr_id_key => 'service_service_id',
        store => 'serviceExtended'
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'extended_service_information',
        attr_id_key => 'service_service_id',
        store => 'serviceExtended'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_service',
        attr_id_key => 'svc_svc_id',
        store => 'serviceMacro',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_service',
        attr_id_key => 'svc_svc_id',
        store => 'serviceMacro',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contact_id',
        store => 'contactServiceRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contact_id',
        store => 'contactServiceRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contactgroup_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpServiceRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contactgroup_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpServiceRelation',
        multiple => 1
    );
}

sub getMappingHostServices {
    my ($self, %options) = @_;

    return $self->{mappingHostServiceIds};
}

sub addMappingHostService {
    my ($self, %options) = @_;

    $self->{mappingHostServiceIds}->{ $options{srcHostId}  . '-' . $options{srcServiceId} } = 
        $options{targetHostId}  . '-' . $options{targetServiceId};
}

sub getTargetHostServiceFromSrc {
    my ($self, %options) = @_;
    
    return undef if (!defined($self->{mappingHostServiceIds}->{ $options{srcHostId}  . '-' . $options{srcServiceId} }));

    my ($hostId, $serviceId) = split(/-/, $self->{mappingHostServiceIds}->{ $options{srcHostId}  . '-' . $options{srcServiceId} });
    return ($hostId, $serviceId);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{load}->{src}->{service}->{byID}->{ $options{srcId} }));

    my $srcName = $self->{load}->{src}->{service}->{byID}->{ $options{srcId} }->{service_description};
    return $self->{load}->{target}->{service}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{service}->{byID}->{ $options{srcId} }->{service_description};
}

sub getSrcIdNameFromName {
    my ($self, %options) = @_;

    return undef if (!defined($options{name}));

    return $self->{load}->{target}->{service}->{byName}->{ $options{name} };
}

sub getNameFromTargetId {
    my ($self, %options) = @_;

    return $self->{load}->{target}->{service}->{byID}->{ $options{targetId} }->{service_description};
}

sub merge {
    my ($self, %options) = @_;

    $self->load();

    my $srcHostServices = $options{host}->getSrcHostServicesRelation();
    foreach my $srcHostId (keys %{$srcHostServices}) {
        next if ($options{host}->isTemplate(srcId => $srcHostId));
 
        foreach my $srcServiceId (@{$srcHostServices->{$srcHostId}}) {
            # We skip BAM services. We don't do it here. It's not in the table because service_register is 2
            next if (!defined($self->{load}->{src}->{service}->{byID}->{$srcServiceId}));

            my $serviceName = $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{service_description}; 
            my $hostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);            

            my $targetHostServices = $options{host}->getTargetHostServicesRelationFromName(name => $hostName);
            my $isAssigned = "";
            foreach (@$targetHostServices) {
                if ($serviceName eq $self->getNameFromTargetId(targetId => $_)) {
                    $isAssigned = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId) . '-' . $_;
                    last;
                }
            }

            if ($isAssigned ne '') {
                $self->{mappingHostServiceIds}->{ $srcHostId . '-' . $srcServiceId } = $isAssigned;
                $self->{logger}->writeLogDebug("service '$hostName - $serviceName': already existed");
                next;
            }

            my $copy = $self->{load}->{src}->{service}->{byID}->{$srcServiceId};
            $copy->{timeperiod_tp_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{timeperiod_tp_id});
            $copy->{timeperiod_tp_id2} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{timeperiod_tp_id2});
            $copy->{command_command_id} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{command_command_id});
            $copy->{command_command_id2} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{command_command_id2});
            $copy->{service_template_model_stm_id} = $options{serviceTpl}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcServiceId}->{service_template_model_stm_id});

            my ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'service',
                name => "$hostName-$serviceName",
                entry => $copy,
                exclude => {
                    service_id => 1
                }
            );

            $self->{load}->{target}->{service}->{byName}->{$serviceName} = $targetId;
            $self->{load}->{target}->{service}->{byID}->{$targetId} = $entry;

            # service host relations
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'host_service_relation',
                name => "$hostName-$serviceName",
                entry => {
                    host_host_id => $options{host}->getTargetIdFromSrcId(srcId => $srcHostId),
                    service_service_id => $targetId
                }
            );

            # extended service
            $copy = $self->{load}->{src}->{serviceExtended}->{$srcServiceId};
            $copy->{service_service_id} = $targetId;
            $copy->{esi_icon_image} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{serviceExtended}->{$srcServiceId}->{esi_icon_image});

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'extended_service_information',
                name => "$hostName-$serviceName",
                entry => $copy,
                exclude => {
                    esi_id => 1
                }
            );

            # contact relations
            foreach my $srcContactId (@{$self->{load}->{src}->{contactServiceRelation}->{$srcServiceId}}) {
                my $contactId = $options{contact}->getTargetIdFromSrcId(srcId => $srcContactId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contact_service_relation',
                    name => "$targetId-$contactId",
                    entry => {
                        service_service_id => $targetId,
                        contact_id => $contactId
                    }
                );
            }

            # contact group relations
            foreach my $srcCgId (@{$self->{load}->{src}->{contactGrpServiceRelation}->{$srcServiceId}}) {
                my $cgId = $options{contactGroup}->getTargetIdFromSrcId(srcId => $srcCgId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contactgroup_service_relation',
                    name => "$targetId-$cgId",
                    entry => {
                        service_service_id => $targetId,
                        contactgroup_cg_id => $cgId
                    }
                );
            }

            # host macro relations
            foreach my $data (@{$self->{load}->{src}->{serviceMacro}->{$srcServiceId}}) {
                $data->{svc_svc_id} = $targetId;
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'on_demand_macro_service',
                    name => "$hostName-$serviceName" . $data->{svc_macro_name},
                    entry => $data,
                    exclude => {
                        svc_macro_id => 1
                    }
                );
            }

            $self->{mappingHostServiceIds}->{ $srcHostId . '-' . $srcServiceId } = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId) . '-' . $targetId;
            $self->{logger}->writeLogInfo("service '$hostName - $serviceName' created");
        }
    }
}

1;

__END__