#!/usr/bin/perl

package objects::contactTpl;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact',
        attr_id => 'contact_id',
        attr_name => 'contact_alias',
        store => 'contact',
        where => "contact_register = '0'",
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact',
        attr_id => 'contact_id',
        attr_name => 'contact_alias',
        where => "contact_register = '0'",
        store => 'contact'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact_hostcommands_relation',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'command_command_id',
        store => 'contactHostcommandsRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact_hostcommands_relation',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'command_command_id',
        store => 'contactHostcommandsRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact_servicecommands_relation',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'command_command_id',
        store => 'contactServicecommandsRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact_servicecommands_relation',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'command_command_id',
        store => 'contactServicecommandsRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_contact_command',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'command_command_id',
        store => 'contactBamcommandsRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_contact_command',
    #    attr_id_key => 'contact_contact_id',
    #    attr_id_value => 'command_command_id',
    #    store => 'contactBamcommandsRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_contact_timeperiod',
        attr_id_key => 'contact_contact_id',
        attr_id_value => 'timeperiod_tp_id',
        store => 'contactBamTpRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_contact_timeperiod',
    #    attr_id_key => 'contact_contact_id',
    #    attr_id_value => 'timeperiod_tp_id',
    #    store => 'contactBamTpRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_contact_notification_options',
        attr_id_key => 'contact_contact_id',
        store => 'contactBamNotificationOptRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_contact_notification_options',
    #    attr_id_key => 'contact_contact_id',
    #    store => 'contactBamNotificationOptRelation',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{contact}->{byID}->{ $options{srcId} }->{contact_alias};
    return $self->{load}->{target}->{contact}->{byName}->{$srcName};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    my $checked = {};
    my @browseID = (values %{$self->{load}->{src}->{contact}->{byName}});
    while ((my $currentID = shift(@browseID))) {
        my $loop = {};
        my @tmpBrowseID = ($currentID);
        while (scalar(@tmpBrowseID) > 0) {            
            if (!defined($loop->{ $tmpBrowseID[0] }) && !defined($checked->{ $tmpBrowseID[0] }) && defined($self->{load}->{src}->{contact}->{byID}->{ $tmpBrowseID[0] }->{contact_template_id})) {
                $loop->{ $tmpBrowseID[0] } = 1;
                unshift(@tmpBrowseID, $self->{load}->{src}->{contact}->{byID}->{ $tmpBrowseID[0] }->{contact_template_id});
                next;
            }

            my $srcId = shift(@tmpBrowseID);
            next if (defined($checked->{$srcId}));
            $checked->{ $srcId } = 1;

            my $name = $self->{load}->{src}->{contact}->{byID}->{$srcId}->{contact_alias};
            if (defined($self->{load}->{target}->{contact}->{byName}->{$name})) {
                $self->{logger}->writeLogInfo("contact template '" . $name . "' already exists");
                next;
            }

            my $copy = $self->{load}->{src}->{contact}->{byID}->{$srcId};
            $copy->{timeperiod_tp_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{contact}->{byID}->{$srcId}->{timeperiod_tp_id});
            $copy->{timeperiod_tp_id2} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{contact}->{byID}->{$srcId}->{timeperiod_tp_id2});
            $copy->{contact_template_id} = $self->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{contact}->{byID}->{$srcId}->{contact_template_id});

            my ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'contact',
                name => $name,
                entry => $copy,
                exclude => {
                    contact_id => 1,
                    show_deprecated_custom_views => 1, # 25.10.x only
                    is_service_account => 1 # 25.10.x only
                }
            );

            $self->{load}->{target}->{contact}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{contact}->{byID}->{$targetId} = $entry;

            # hostcommand relations
            foreach my $srcHostcommandID (@{$self->{load}->{src}->{contactHostcommandsRelation}->{$srcId}}) {
                my $commandId = $options{command}->getTargetIdFromSrcId(srcId => $srcHostcommandID);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contact_hostcommands_relation',
                    name => "$targetId-$commandId",
                    entry => {
                        contact_contact_id => $targetId,
                        command_command_id => $commandId
                    }
                );
            }

            # servicecommand relations
            foreach my $srcServicecommandID (@{$self->{load}->{src}->{contactServicecommandsRelation}->{$srcId}}) {
                my $commandId = $options{command}->getTargetIdFromSrcId(srcId => $srcServicecommandID);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contact_servicecommands_relation',
                    name => "$targetId-$commandId",
                    entry => {
                        contact_contact_id => $targetId,
                        command_command_id => $commandId
                    }
                );
            }

            # bam command relations
            foreach my $srcBamcommandID (@{$self->{load}->{src}->{contactBamcommandsRelation}->{$srcId}}) {
                my $commandId = $options{command}->getTargetIdFromSrcId(srcId => $srcBamcommandID);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'mod_bam_contact_command',
                    name => "$targetId-$commandId",
                    entry => {
                        contact_contact_id => $targetId,
                        command_command_id => $commandId
                    }
                );
            }
 
            # bam timeperiod relations
            foreach my $srcBamTpID (@{$self->{load}->{src}->{contactBamTpRelation}->{$srcId}}) {
                my $tpId = $options{timeperiod}->getTargetIdFromSrcId(srcId => $srcBamTpID);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'mod_bam_contact_timeperiod',
                    name => "$targetId-$tpId",
                    entry => {
                        contact_contact_id => $targetId,
                        timeperiod_tp_id => $tpId
                    }
                );
            }

            # bam notification options relations
            foreach my $data (@{$self->{load}->{src}->{contactBamNotificationOptRelation}->{$srcId}}) {
                $data->{contact_contact_id} = $targetId;
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'mod_bam_contact_notification_options',
                    name => "$targetId-notification-options",
                    entry => $data
                );
            }

            $self->{logger}->writeLogInfo("contact template '" . $name . "' created");
        }
    }
}

1;

__END__