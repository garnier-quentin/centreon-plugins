#!/usr/bin/perl

package objects::host;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{map_poller_relations} = {
        # src => dst
        1 => 1
    };

    $self->{mappingHostIds} = {};
    $self->{mappingHostServiceIds} = {};

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'host',
        attr_id => 'host_id',
        attr_name => 'host_name',
        store => 'host',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'host',
        attr_id => 'host_id',
        attr_name => 'host_name',
        store => 'host'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'extended_host_information',
        attr_id_key => 'host_host_id',
        store => 'hostExtended'
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'extended_host_information',
        attr_id_key => 'host_host_id',
        store => 'hostExtended'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'host_template_relation',
        attr_id_key => 'host_host_id',
        store => 'hostTplRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'host_template_relation',
        attr_id_key => 'host_host_id',
        store => 'hostTplRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_host',
        attr_id_key => 'host_host_id',
        store => 'hostMacro',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_host',
        attr_id_key => 'host_host_id',
        store => 'hostMacro',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact_host_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'contact_id',
        store => 'contactHostRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact_host_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'contact_id',
        store => 'contactHostRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contactgroup_host_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpHostRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contactgroup_host_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpHostRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'ns_host_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'nagios_server_id',
        store => 'nsHostRelation'
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'ns_host_relation',
    #    attr_id_key => 'host_host_id',
    #    attr_id_value => 'nagios_server_id',
    #    store => 'nsHostRelation'
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'host_service_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'service_service_id',
        store => 'hostServiceRelation',
        where => "host_host_id IS NOT NULL AND service_service_id IS NOT NULL",
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'host_service_relation',
        attr_id_key => 'host_host_id',
        attr_id_value => 'service_service_id',
        store => 'hostServiceRelation',
        where => "host_host_id IS NOT NULL AND service_service_id IS NOT NULL",
        multiple => 1
    );
}

sub getMappingHosts {
    my ($self, %options) = @_;

    return $self->{mappingHostIds};
}

# for template relation only
sub getTargetHostServiceFromSrc {
    my ($self, %options) = @_;
    
    return undef if (!defined($self->{mappingHostServiceIds}->{ $options{srcHostId}  . '-' . $options{srcServiceId} }));

    my ($hostId, $serviceId) = split(/-/, $self->{mappingHostServiceIds}->{ $options{srcHostId}  . '-' . $options{srcServiceId} });
    return ($hostId, $serviceId);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{host}->{byID}->{ $options{srcId} }->{host_name};
    return $self->{load}->{target}->{host}->{byName}->{$srcName};
}

sub getTargetIdFromName {
    my ($self, %options) = @_;

    return undef if (!defined($options{name}));

    return $self->{load}->{target}->{host}->{byName}->{ $options{name} };
}

sub getSrcIdFromName {
    my ($self, %options) = @_;

    return undef if (!defined($options{name}));

    return $self->{load}->{src}->{host}->{byName}->{ $options{name} };
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{host}->{byID}->{ $options{srcId} }->{host_name};
}

sub getSrcHostServicesRelation {
    my ($self, %options) = @_;

    return $self->{load}->{src}->{hostServiceRelation};
}

sub getTargetHostServicesRelationFromName {
    my ($self, %options) = @_;

    return $self->{load}->{target}->{hostServiceRelation}->{ $self->{load}->{target}->{host}->{byName}->{ $options{name} } };
}

sub getTargetPollerIdFromSrcId {
    my ($self, %options) = @_;

    return $self->{map_poller_relations}->{ $options{srcId} };
}

sub isTemplate {
    my ($self, %options) = @_;

    return 1 if ($self->{load}->{src}->{host}->{byID}->{ $options{srcId} }->{host_register} == 0);

    return 0;
}

sub merge {
    my ($self, %options) = @_;

    $self->load();

    my $checked = {};
    my @browseID = (values %{$self->{load}->{src}->{host}->{byName}});
    while ((my $currentID = shift(@browseID))) {
        my $loop = {};
        my @tmpBrowseID = ($currentID);
        while (scalar(@tmpBrowseID) > 0) {
            if (!defined($loop->{ $tmpBrowseID[0] }) && !defined($checked->{ $tmpBrowseID[0] }) && defined($self->{load}->{src}->{hostTplRelation}->{ $tmpBrowseID[0] })) {
                $loop->{ $tmpBrowseID[0] } = 1;
                foreach (@{$self->{load}->{src}->{hostTplRelation}->{ $tmpBrowseID[0] }}) {
                    if (!defined($checked->{ $_->{host_tpl_id} })) {
                        unshift(@tmpBrowseID, $_->{host_tpl_id});
                    }
                    
                }
                
                next;
            }

            my $srcId = shift(@tmpBrowseID);
                        
            next if (defined($checked->{$srcId}));
            $checked->{ $srcId } = 1;

            my $name = $self->{load}->{src}->{host}->{byID}->{$srcId}->{host_name};
            if (defined($self->{load}->{target}->{host}->{byName}->{$name})) {
                $self->{logger}->writeLogInfo("host '" . $name . "' already exists");
                $self->{mappingHostIds}->{$srcId} = $self->{load}->{target}->{host}->{byName}->{$name}
                    if ($self->{load}->{src}->{host}->{byID}->{$srcId}->{host_register} != 0);
                next;
            }

            my $copy = $self->{load}->{src}->{host}->{byID}->{$srcId};
            $copy->{timeperiod_tp_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{host}->{byID}->{$srcId}->{timeperiod_tp_id});
            $copy->{timeperiod_tp_id2} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{host}->{byID}->{$srcId}->{timeperiod_tp_id2});
            $copy->{command_command_id} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{host}->{byID}->{$srcId}->{command_command_id});
            $copy->{command_command_id2} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{host}->{byID}->{$srcId}->{command_command_id2});

            my ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'host',
                name => $name,
                entry => $copy,
                exclude => {
                    host_id => 1
                }
            );

            $self->{load}->{target}->{host}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{host}->{byID}->{$targetId} = $entry;

            $self->{mappingHostIds}->{$srcId} = $targetId 
                if ($self->{load}->{src}->{host}->{byID}->{$srcId}->{host_register} != 0);

            # extended host
            $copy = $self->{load}->{src}->{hostExtended}->{$srcId};
            $copy->{host_host_id} = $targetId;
            $copy->{ehi_icon_image} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{hostExtended}->{$srcId}->{ehi_icon_image});
            $copy->{ehi_statusmap_image} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{hostExtended}->{$srcId}->{ehi_statusmap_image});

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'extended_host_information',
                name => $name,
                entry => $copy,
                exclude => {
                    ehi_id => 1
                }
            );

            # poller relations
            if ($self->{load}->{src}->{host}->{byID}->{$srcId}->{host_register} == 1) {
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'ns_host_relation',
                    name => $name,
                    entry => {
                        host_host_id => $targetId,
                        nagios_server_id => $self->{map_poller_relations}->{ $self->{load}->{src}->{nsHostRelation}->{$srcId} }
                    }
                );
            }

            # contact relations
            foreach my $srcContactId (@{$self->{load}->{src}->{contactHostRelation}->{$srcId}}) {
                my $contactId = $options{contact}->getTargetIdFromSrcId(srcId => $srcContactId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contact_host_relation',
                    name => "$targetId-$contactId",
                    entry => {
                        host_host_id => $targetId,
                        contact_id => $contactId
                    }
                );
            }

            # contact group relations
            foreach my $srcCgId (@{$self->{load}->{src}->{contactGrpHostRelation}->{$srcId}}) {
                my $cgId = $options{contactGroup}->getTargetIdFromSrcId(srcId => $srcCgId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contactgroup_host_relation',
                    name => "$targetId-$cgId",
                    entry => {
                        host_host_id => $targetId,
                        contactgroup_cg_id => $cgId
                    }
                );
            }

            # host template relations
            foreach my $data (@{$self->{load}->{src}->{hostTplRelation}->{$srcId}}) {
                my $hostId = $self->getTargetIdFromSrcId(srcId => $data->{host_tpl_id});
                $data->{host_host_id} = $targetId;
                $data->{host_tpl_id} = $hostId;
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'host_template_relation',
                    name => "$targetId-$hostId",
                    entry => $data
                );
            }
 
            # host macro relations
            foreach my $data (@{$self->{load}->{src}->{hostMacro}->{$srcId}}) {
                $data->{host_host_id} = $targetId;
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'on_demand_macro_host',
                    name => "$targetId-" . $data->{host_macro_name},
                    entry => $data,
                    exclude => {
                        host_macro_id => 1
                    }
                );
            }

            # host template <---- service template relation : only for new host template 
            if ($self->{load}->{src}->{host}->{byID}->{$srcId}->{host_register} == 0) {
                foreach my $srcServiceId (@{$self->{load}->{src}->{hostServiceRelation}->{$srcId}}) {
                    my $serviceId = $options{serviceTpl}->getTargetIdFromSrcId(srcId => $srcServiceId);
                    $self->insertTable(
                        instance => 'target',
                        db_name => 'centreon',
                        tbl_name => 'host_service_relation',
                        name => "$targetId-$serviceId",
                        entry => {
                            host_host_id => $targetId,
                            service_service_id => $serviceId
                        }
                    );
                    
                    $self->{mappingHostServiceIds}->{ $srcId . '-' . $srcServiceId } = "$targetId-$serviceId";
                }
            }
 
            $self->{logger}->writeLogInfo("host '" . $name . "' created");
        }
    }
}

1;

__END__