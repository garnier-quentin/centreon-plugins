#!/usr/bin/perl

package objects::bamKpi;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{mapping_kpi} = {}; 

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_kpi',
        attr_id_key => 'id_ba',
        store => 'bamKpi',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_kpi',
    #    attr_id_key => 'id_ba',
    #    store => 'bamKpi',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{mapping_kpi}->{ $options{srcId} }));

    return $self->{mapping_kpi}->{ $options{srcId} };
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcBaId (keys %{$self->{load}->{src}->{bamKpi}}) {
        next if (!$options{bamBa}->isBaCreated(srcBaId => $srcBaId));

        my $name = $options{bamBa}->getNameFromSrcId(srcId => $srcBaId);
        
        foreach my $data (@{$self->{load}->{src}->{bamKpi}->{$srcBaId}}) {
            $data->{boolean_id} = $options{bamBoolean}->getTargetIdFromSrcId(srcId => $data->{boolean_id});
            $data->{id_indicator_ba} = $options{bamBa}->getTargetIdFromSrcId(srcId => $data->{id_indicator_ba});
            if (defined($data->{service_id})) {
                my ($hostId, $serviceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $data->{host_id}, srcServiceId => $data->{service_id});
                $data->{host_id} = $hostId;
                $data->{service_id} = $serviceId;
            }

            my ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_kpi',
                name => $name,
                entry => $data,
                exclude => {
                    kpi_id => 1
                }
            );

            $self->{mapping_kpi}->{ $data->{kpi_id} } = $targetId;

            $self->{logger}->writeLogDebug("bam '" . $name . "' kpi created");
        }
    }
}

1;

__END__