#!/usr/bin/perl

package objects::aclMenu;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_topology',
        attr_id => 'acl_topo_id',
        attr_name => 'acl_topo_name',
        store => 'aclTopology',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_topology',
        attr_id => 'acl_topo_id',
        attr_name => 'acl_topo_name',
        store => 'aclTopology'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_topology_relations',
        attr_id_key => 'acl_topo_id',
        store => 'aclToplogyRelations',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_topology_relations',
        attr_id_key => 'acl_topo_id',
        store => 'aclToplogyRelations',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    my $srcName = $self->{load}->{src}->{aclTopology}->{byID}->{ $options{srcId} }->{acl_topo_name};
    return $self->{load}->{target}->{aclTopology}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{aclTopology}->{byID}->{ $options{srcId} }->{acl_topo_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{aclTopology}->{byID}}) {
        my $name = $self->{load}->{src}->{aclTopology}->{byID}->{$srcId}->{acl_topo_name};
        if (defined($self->{load}->{target}->{aclTopology}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("acl menu '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'acl_topology',
            name => $name,
            entry => $self->{load}->{src}->{aclTopology}->{byID}->{$srcId},
            exclude => {
                acl_topo_id => 1
            }
        );

        $self->{load}->{target}->{aclTopology}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{aclTopology}->{byID}->{$targetId} = $entry;

        # acl menu relations
        foreach my $data (@{$self->{load}->{src}->{aclToplogyRelations}->{$srcId}}) {
            $data->{acl_topo_id} = $targetId;
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_topology_relations',
                name => $data->{acl_topo_name},
                entry => $data
            );
        }

        $self->{logger}->writeLogInfo("acl menu '" . $name . "' created");
    }
}

1;

__END__