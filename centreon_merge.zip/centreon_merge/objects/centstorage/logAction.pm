#!/usr/bin/perl

package objects::centstorage::logAction;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("log_action merge in progress");

    my $inserted = 0;
    my $map_action = {};

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'log_action', requestId => 'log_action')})
        )
    ) {
        if ($row->{object_type} eq 'resource access') {
            $row->{object_id} = $options{aclResource}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'menu access') {
            $row->{object_id} = $options{aclMenu}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'access group') {
            $row->{object_id} = $options{aclGroup}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'action access') {
            $row->{object_id} = $options{aclAction}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'contact') {
            my $object_id = $options{contact}->getTargetIdFromSrcId(srcId => $row->{object_id});
            if (!defined($object_id)) {
                $object_id = $options{contactTpl}->getTargetIdFromSrcId(srcId => $row->{object_id});
            }
            $row->{object_id} = $object_id;
        } elsif ($row->{object_type} eq 'servicecategories') {
            $row->{object_id} = $options{serviceCategory}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'servicegroup') {
            $row->{object_id} = $options{serviceGroup}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'hostcategories') {
            $row->{object_id} = $options{hostCategory}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'hostgroup') {
            $row->{object_id} = $options{hostGroup}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'contactgroup') {
            $row->{object_id} = $options{contactGroup}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'command') {
            $row->{object_id} = $options{command}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'timeperiod') {
            $row->{object_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'host') {
            $row->{object_id} = $options{host}->getTargetIdFromSrcId(srcId => $row->{object_id});
        } elsif ($row->{object_type} eq 'service') {
            my $object_id = $options{serviceTpl}->getTargetIdFromSrcId(srcId => $row->{object_id});
            if (!defined($object_id)) {
                $object_id = $options{service}->getTargetIdFromSrcId(srcId => $row->{object_id});
            }
            $row->{object_id} = $object_id;
        } else {
            next;
        }

        next if (!defined($row->{object_id}));

        $row->{log_contact_id} = $options{contact}->getTargetIdFromSrcId(srcId => $row->{log_contact_id});

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'log_action',
            name => 'log_action-' . $row->{object_name},
            entry => $row,
            exclude => {
                action_log_id => 1
            }
        );

        $map_action->{ $row->{action_log_id} } = $targetId;

        $inserted++;
    }

    $self->{logger}->writeLogInfo("log_action number of rows inserted " . $inserted);


    $self->{logger}->writeLogInfo("log_action_modification merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'log_action_modification', requestId => 'lam')})
        )
    ) {
        # not imported
        next if (!defined($map_action->{ $row->{action_log_id} }));

        $row->{action_log_id} = $map_action->{ $row->{action_log_id} };

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'log_action_modification',
            requestId => 'lam',
            entry => $row,
            exclude => {
                modification_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'log_action_modification',
        requestId => 'lam',
        force => 1,
        exclude => {
            modification_id => 1
        }
    );

    $self->{logger}->writeLogInfo("log_action_modification number of rows inserted " . $self->getNumberRowsInsert(requestId => 'lam'));
}

1;

__END__