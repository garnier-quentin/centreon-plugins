#!/usr/bin/perl

package objects::centstorage::metrics;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;
    $self->{metrics_filename} = $options{metrics_filename};

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    my ($rows, $inserted);

    $self->{logger}->writeLogInfo("index_data merge in progress");
    $inserted = 0;
    my $map_metrics = {
        rrd_status => {},
        rrd_metrics => {}
    };

    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'index_data', requestId => 'index_data')})
        )
    ) {
        my ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
        # service doesn't exist anymore
        next if (!defined($targetHostId));

        $row->{host_id} = $targetHostId;
        $row->{service_id} = $targetServiceId;

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'index_data',
            name => 'index_data',
            entry => $row,
            exclude => {
                id => 1
            }
        );

        $map_metrics->{rrd_status}->{ $row->{id} } = $targetId;
        $inserted++;
    }

    $self->{logger}->writeLogInfo("index_data number of rows inserted " . $inserted);

    $inserted = 0;
    $self->{logger}->writeLogInfo("metrics merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'metrics', requestId => 'metrics')})
        )
    ) {
        # not imported
        next if (!defined($map_metrics->{rrd_status}->{ $row->{index_id} }));

        $row->{index_id} = $map_metrics->{rrd_status}->{ $row->{index_id} };

         my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'metrics',
            name => 'metrics',
            entry => $row,
            exclude => {
                metric_id => 1
            }
        );

        $map_metrics->{rrd_metrics}->{ $row->{metric_id} } = $targetId;
        $inserted++;
    }

    $self->{logger}->writeLogInfo("metrics number of rows inserted " . $inserted);

    $self->writeFile(value => $map_metrics, filename => $self->{metrics_filename});
}

1;

__END__