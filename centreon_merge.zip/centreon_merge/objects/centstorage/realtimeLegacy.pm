#!/usr/bin/perl

package objects::centstorage::realtimeLegacy;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub addInstances {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centstorage',
        tbl_name => 'instances',
        attr_id => 'instance_id',
        attr_name => 'name',
        store => 'instances',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'instances',
        attr_id => 'instance_id',
        attr_name => 'name',
        store => 'instances'
    );

    foreach my $srcId (keys %{$self->{load}->{src}->{instances}->{byID}}) {
        my $name = $self->{load}->{src}->{instances}->{byID}->{$srcId}->{name};

        my $instanceId = $options{host}->getTargetPollerIdFromSrcId(srcId => $self->{load}->{src}->{instances}->{byID}->{$srcId}->{instance_id});
        next if (!defined($instanceId));

        if (defined($self->{load}->{target}->{instances}->{byID}->{$instanceId})) {
            $self->{logger}->writeLogInfo("realtime legacy instance '$instanceId-" . $name . "' already exists");
            next;
        }

        my $copy = $self->{load}->{src}->{instances}->{byID}->{$srcId};
        $copy->{instance_id} = $instanceId;

        $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'instances',
            name => $name,
            entry => $copy
        );

        $self->{logger}->writeLogInfo("realtime legacy instance '$instanceId-" . $name . "' created");
    }
}

sub addHosts {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centstorage',
        tbl_name => 'hosts',
        attr_id => 'host_id',
        attr_name => 'name',
        store => 'hosts',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'hosts',
        attr_id => 'host_id',
        attr_name => 'name',
        store => 'hosts'
    );

    foreach my $srcId (keys %{$self->{load}->{src}->{hosts}->{byID}}) {
        my $name = $self->{load}->{src}->{hosts}->{byID}->{$srcId}->{name};
        my $copy = $self->{load}->{src}->{hosts}->{byID}->{$srcId};

        my $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $copy->{host_id});
        next if (!defined($targetHostId));

        my $instanceId = $options{host}->getTargetPollerIdFromSrcId(srcId => $copy->{instance_id});
        next if (!defined($instanceId));

        if (defined($self->{load}->{target}->{hosts}->{byID}->{$targetHostId})) {
            $self->{logger}->writeLogInfo("realtime legacy host '" . $name . "' already exists");
            next;
        }

        $copy->{host_id} = $targetHostId;
        $copy->{instance_id} = $instanceId;

        $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'hosts',
            name => $name,
            entry => $copy
        );

        $self->{logger}->writeLogInfo("realtime legacy host '" . $name . "' created");
    }
}

sub addServices {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("realtime legacy services merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'services', requestId => 'services')})
        )
    ) {
        my ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
        # service doesn't exist anymore
        next if (!defined($targetHostId));

        $row->{host_id} = $targetHostId;
        $row->{service_id} = $targetServiceId;

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'services',
            requestId => 'services',
            entry => $row,
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'services',
        requestId => 'services',
        force => 1
    );

    $self->{logger}->writeLogInfo("realtime legacy services number of rows inserted " . $self->getNumberRowsInsert(requestId => 'services'));
}

sub merge {
    my ($self, %options) = @_;

   $self->addInstances(%options);
   $self->addHosts(%options);
   $self->addServices(%options);
}

1;

__END__