#!/usr/bin/perl

package objects::centstorage::logs;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("logs merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'logs', requestId => 'logs')})
        )
    ) {
        if (defined($row->{host_id}) && $row->{host_id} > 0) {
            my ($targetHostId, $targetServiceId);
            $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $row->{host_id});
            # host doesn't exist anymore
            next if (!defined($targetHostId));

            if (defined($row->{service_id}) && $row->{service_id} > 0) {
                ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
                # service doesn't exist anymore
                next if (!defined($targetHostId));

                $row->{service_id} = $targetServiceId;
            }

            $row->{host_id} = $targetHostId;
        }

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'logs',
            requestId => 'logs',
            entry => $row,
            exclude => {
                log_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'logs',
        requestId => 'logs',
        force => 1,
        exclude => {
            log_id => 1
        }
    );

    $self->{logger}->writeLogInfo("logs number of rows inserted " . $self->getNumberRowsInsert(requestId => 'logs'));
}

1;

__END__