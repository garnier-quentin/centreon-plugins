#!/usr/bin/perl

package objects::centstorage::hostStateEvents;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("hoststateevents merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'hoststateevents', requestId => 'hse')})
        )
    ) {
        my $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $row->{host_id});
        # host doesn't exist anymore
        next if (!defined($targetHostId));   
        $row->{host_id} = $targetHostId;

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'hoststateevents',
            requestId => 'hse',
            entry => $row,
            exclude => {
                hoststateevent_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'hoststateevents',
        requestId => 'hse',
        force => 1,
        exclude => {
            hoststateevent_id => 1
        }
    );

    $self->{logger}->writeLogInfo("hoststateevents number of rows inserted " . $self->getNumberRowsInsert(requestId => 'hse'));
}

1;

__END__