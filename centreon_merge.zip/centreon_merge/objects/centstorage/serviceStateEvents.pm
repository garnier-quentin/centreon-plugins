#!/usr/bin/perl

package objects::centstorage::serviceStateEvents;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("servicestateevents merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'servicestateevents', requestId => 'sse')})
        )
    ) {
        my ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
        # service doesn't exist anymore
        next if (!defined($targetHostId));

        $row->{host_id} = $targetHostId;
        $row->{service_id} = $targetServiceId;

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'servicestateevents',
            requestId => 'sse',
            entry => $row,
            exclude => {
                servicestateevent_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'servicestateevents',
        requestId => 'sse',
        force => 1,
        exclude => {
            servicestateevent_id => 1
        }
    );

    $self->{logger}->writeLogInfo("servicestateevents number of rows inserted " . $self->getNumberRowsInsert(requestId => 'sse'));
}

1;

__END__