#!/usr/bin/perl

package objects::centstorage::logArchiveHost;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    $self->{logger}->writeLogInfo("log_archive_host merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'log_archive_host', requestId => 'lah')})
        )
    ) {
        my $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $row->{host_id});
        # host doesn't exist anymore
        next if (!defined($targetHostId));   
        $row->{host_id} = $targetHostId;

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'log_archive_host',
            requestId => 'lah',
            entry => $row,
            exclude => {
                log_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'log_archive_host',
        requestId => 'lah',
        force => 1,
        exclude => {
            log_id => 1
        }
    );

    $self->{logger}->writeLogInfo("log_archive_host number of rows inserted " . $self->getNumberRowsInsert(requestId => 'lah'));
}

1;

__END__