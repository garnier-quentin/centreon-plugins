#!/usr/bin/perl

package objects::centstorage::bamEvents;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub addTimeperiod {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_timeperiods',
        attr_id => 'timeperiod_id',
        attr_name => 'name',
        store => 'bamReportingTp',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_timeperiods',
        attr_id => 'timeperiod_id',
        attr_name => 'name',
        store => 'bamReportingTp'
    );

    foreach my $srcId (keys %{$self->{load}->{src}->{bamReportingTp}->{byID}}) {
        my $name = $self->{load}->{src}->{bamReportingTp}->{byID}->{$srcId}->{name};
        if (defined($self->{load}->{target}->{bamReportingTp}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("bam reporting timeperiod '" . $name . "' already exists");
            next;
        }

        my $copy = $self->{load}->{src}->{bamReportingTp}->{byID}->{$srcId};
        $copy->{timeperiod_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $copy->{timeperiod_id});
        next if (!defined($copy->{timeperiod_id}));
        
        $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_timeperiods',
            name => $name,
            entry => $copy
        );

        $self->{logger}->writeLogInfo("bam reporting timeperiod '" . $name . "' created");
    }
}

sub merge {
    my ($self, %options) = @_;

    $self->addTimeperiod(%options);

    my ($rows, $inserted);

    $self->{logger}->writeLogInfo("mod_bam_reporting_ba merge in progress");
    $inserted = 0;

    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_ba', requestId => 'mbrba')})
        )
    ) {
        $row->{ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{ba_id});
        next if (!defined($row->{ba_id}));

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_ba',
            name => 'mod_bam_reporting_ba',
            entry => $row
        );

        $inserted++;
    }

    $self->{logger}->writeLogInfo("mod_bam_reporting_ba number of rows inserted " . $inserted);


    $self->{logger}->writeLogInfo("mod_bam_reporting_bv merge in progress");
    $inserted = 0;

    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_bv', requestId => 'mbrbv')})
        )
    ) {
        $row->{bv_id} = $options{bamBaGroups}->getTargetIdFromSrcId(srcId => $row->{bv_id});
        next if (!defined($row->{bv_id}));

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_bv',
            name => 'mod_bam_reporting_bv',
            entry => $row
        );

        $inserted++;
    }

    $self->{logger}->writeLogInfo("mod_bam_reporting_bv number of rows inserted " . $inserted);


    $self->{logger}->writeLogInfo("mod_bam_reporting_ba_events merge in progress");
    $inserted = 0;
    my $map_ba_event = {};

    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_ba_events', requestId => 'mbrbe')})
        )
    ) {
        $row->{ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{ba_id});
        next if (!defined($row->{ba_id}));

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_ba_events',
            name => 'mod_bam_reporting_ba_events',
            entry => $row,
            exclude => {
                ba_event_id => 1
            }
        );
        $map_ba_event->{ $row->{ba_event_id} } = $targetId;

        $inserted++;
    }

    $self->{logger}->writeLogInfo("mod_bam_reporting_ba_events number of rows inserted " . $inserted);


    $self->{logger}->writeLogInfo("mod_bam_reporting_ba_events_durations merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_ba_events_durations', requestId => 'mbrbed')})
        )
    ) {
        # not imported
        next if (!defined($map_ba_event->{ $row->{ba_event_id} }));

        $row->{ba_event_id} = $map_ba_event->{ $row->{ba_event_id} };
        $row->{timeperiod_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $row->{timeperiod_id});
        
        next if (!defined($row->{timeperiod_id}));

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_ba_events_durations',
            requestId => 'mbrbed',
            entry => $row,
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_ba_events_durations',
        requestId => 'mbrbed',
        force => 1
    );

    $self->{logger}->writeLogInfo("mod_bam_reporting_ba_events_durations number of rows inserted " . $self->getNumberRowsInsert(requestId => 'mbrbed'));


    $self->{logger}->writeLogInfo("mod_bam_reporting_kpi merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_kpi', requestId => 'mbrkpi')})
        )
    ) {
        $row->{ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{ba_id});
        next if (!defined($row->{ba_id}));

        $row->{kpi_id} = $options{bamKpi}->getTargetIdFromSrcId(srcId => $row->{kpi_id});
        next if (!defined($row->{kpi_id}));

        if (defined($row->{boolean_id}) && $row->{boolean_id} > 0) {
            $row->{boolean_id} = $options{bamBoolean}->getTargetIdFromSrcId(srcId => $row->{boolean_id});
        }
        if (defined($row->{kpi_ba_id}) && $row->{kpi_ba_id} > 0) {
            $row->{kpi_ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{kpi_ba_id});
        }
        if (defined($row->{service_id}) && $row->{service_id} > 0) {
            my ($hostId, $serviceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
            $row->{host_id} = $hostId;
            $row->{service_id} = $serviceId;
        }

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_kpi',
            requestId => 'mbrkpi',
            entry => $row,
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_kpi',
        requestId => 'mbrkpi',
        force => 1
    );

    $self->{logger}->writeLogInfo("mod_bam_reporting_kpi number of rows inserted " . $self->getNumberRowsInsert(requestId => 'mbrkpi'));


    $self->{logger}->writeLogInfo("mod_bam_reporting_kpi_events merge in progress");
    $inserted = 0;
    my $map_kpi_event = {};

    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_kpi_events', requestId => 'mbrkpie')})
        )
    ) {
        $row->{kpi_id} = $options{bamKpi}->getTargetIdFromSrcId(srcId => $row->{kpi_id});
        next if (!defined($row->{kpi_id}));

        my ($targetId) = $self->insertTable(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_kpi_events',
            name => 'mod_bam_reporting_kpi_events',
            entry => $row,
            exclude => {
                kpi_event_id => 1
            }
        );
        $map_kpi_event->{ $row->{kpi_event_id} } = $targetId;

        $inserted++;
    }

    $self->{logger}->writeLogInfo("mod_bam_reporting_kpi_events number of rows inserted " . $inserted);


    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_kpi_events merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_relations_ba_kpi_events', requestId => 'mbrrbakpie')})
        )
    ) {
        # not imported
        next if (!defined($map_ba_event->{ $row->{ba_event_id} }));
        next if (!defined($map_kpi_event->{ $row->{kpi_event_id} }));

        $row->{ba_event_id} = $map_ba_event->{ $row->{ba_event_id} };
        $row->{kpi_event_id} = $map_kpi_event->{ $row->{kpi_event_id} };
        
        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_relations_ba_kpi_events',
            requestId => 'mbrrbakpie',
            entry => $row,
            bulkInsert => $self->{bulkInsert},
            exclude => {
                relation_id => 1
            }
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_relations_ba_kpi_events',
        requestId => 'mbrrbakpie',
        force => 1,
        exclude => {
            relation_id => 1
        }
    );

    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_kpi_events number of rows inserted " . $self->getNumberRowsInsert(requestId => 'mbrrbakpie'));


    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_bv merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_relations_ba_bv', requestId => 'mbrrbb')})
        )
    ) {
        $row->{ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{ba_id});
        next if (!defined($row->{ba_id}));

        $row->{bv_id} = $options{bamBaGroups}->getTargetIdFromSrcId(srcId => $row->{bv_id});
        next if (!defined($row->{bv_id}));
        
        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_relations_ba_bv',
            requestId => 'mbrrbb',
            entry => $row,
            bulkInsert => $self->{bulkInsert},
            exclude => {
                ba_bv_id => 1
            }
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_relations_ba_bv',
        requestId => 'mbrrbb',
        force => 1,
        exclude => {
            ba_bv_id => 1
        }
    );

    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_bv number of rows inserted " . $self->getNumberRowsInsert(requestId => 'mbrrbb'));


    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_timeperiods merge in progress");
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'mod_bam_reporting_relations_ba_timeperiods', requestId => 'mbrrbtp')})
        )
    ) {
        $row->{ba_id} = $options{bamBa}->getTargetIdFromSrcId(srcId => $row->{ba_id});
        next if (!defined($row->{ba_id}));

        $row->{timeperiod_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $row->{timeperiod_id});
        next if (!defined($row->{timeperiod_id}));
        
        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'mod_bam_reporting_relations_ba_timeperiods',
            requestId => 'mbrrbtp',
            entry => $row,
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'mod_bam_reporting_relations_ba_timeperiods',
        requestId => 'mbrrbtp',
        force => 1
    );

    $self->{logger}->writeLogInfo("mod_bam_reporting_relations_ba_timeperiods number of rows inserted " . $self->getNumberRowsInsert(requestId => 'mbrrbtp'));
}

1;

__END__