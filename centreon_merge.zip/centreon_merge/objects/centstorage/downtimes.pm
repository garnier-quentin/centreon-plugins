#!/usr/bin/perl

package objects::centstorage::downtimes;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{bulkInsert} = 10000;

    bless $self, $class;
    return $self;
}

sub merge {
    my ($self, %options) = @_;

    # internal_id is used in retention.dat. don't need to touch it. no need of mapping system to replace.

   $self->{logger}->writeLogInfo("downtimes merge in progress");

    my $rows;
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $self->getRowsChunck(instance => 'src', db_name => 'centstorage', tbl_name => 'downtimes', requestId => 'downtimes')})
        )
    ) {
        if (defined($row->{host_id}) && $row->{host_id} > 0) {
            my ($targetHostId, $targetServiceId);
            $targetHostId = $options{host}->getTargetIdFromSrcId(srcId => $row->{host_id});
            # host doesn't exist anymore
            next if (!defined($targetHostId));

            if (defined($row->{service_id}) && $row->{service_id} > 0) {
                ($targetHostId, $targetServiceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $row->{host_id}, srcServiceId => $row->{service_id});
                # service doesn't exist anymore
                next if (!defined($targetHostId));

                $row->{service_id} = $targetServiceId;
            }

            $row->{host_id} = $targetHostId;
        }

        $row->{instance_id} = $options{host}->getTargetPollerIdFromSrcId(srcId => $row->{instance_id});
        next if (!defined($row->{instance_id}));

        $self->addRowMultiple(
            instance => 'target',
            db_name => 'centstorage',
            tbl_name => 'downtimes',
            requestId => 'downtimes',
            entry => $row,
            exclude => {
                downtime_id => 1
            },
            bulkInsert => $self->{bulkInsert}
        );
    }

    $self->addRowMultiple(
        instance => 'target',
        db_name => 'centstorage',
        tbl_name => 'downtimes',
        requestId => 'downtimes',
        force => 1,
        exclude => {
            downtime_id => 1
        }
    );

    $self->{logger}->writeLogInfo("downtimes number of rows inserted " . $self->getNumberRowsInsert(requestId => 'downtimes'));
}

1;

__END__