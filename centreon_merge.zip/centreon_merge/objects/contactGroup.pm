#!/usr/bin/perl

package objects::contactGroup;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contactgroup',
        attr_id => 'cg_id',
        attr_name => 'cg_name',
        store => 'contactgroup',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contactgroup',
        attr_id => 'cg_id',
        attr_name => 'cg_name',
        store => 'contactgroup'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contactgroup_contact_relation',
        attr_id_key => 'contactgroup_cg_id',
        attr_id_value => 'contact_contact_id',
        store => 'cgContactRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contactgroup_contact_relation',
        attr_id_key => 'contactgroup_cg_id',
        attr_id_value => 'contact_contact_id',
        store => 'cgContactRelation',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{contactgroup}->{byID}->{ $options{srcId} }->{cg_name};
    return $self->{load}->{target}->{contactgroup}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{contactgroup}->{byID}->{ $options{srcId} }->{cg_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{contactgroup}->{byID}}) {
        my $name = $self->{load}->{src}->{contactgroup}->{byID}->{$srcId}->{cg_name};

        my ($targetId, $entry); 
        if (defined($self->{load}->{target}->{contactgroup}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("contact group '" . $name . "' already exists");
            $targetId = $self->{load}->{target}->{contactgroup}->{byName}->{$name};
        } else {
            ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'contactgroup',
                name => $name,
                entry => $self->{load}->{src}->{contactgroup}->{byID}->{$srcId},
                exclude => {
                    cg_id => 1
                }
            );

            $self->{load}->{target}->{contactgroup}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{contactgroup}->{byID}->{$targetId} = $entry;

            $self->{logger}->writeLogInfo("contact group '" . $name . "' created");
        }

        foreach my $srcCgContactId (@{$self->{load}->{src}->{cgContactRelation}->{$srcId}}) {
            my $contactId = $options{contact}->getTargetIdFromSrcId(srcId => $srcCgContactId);
            my $displayContactName = $options{contact}->getNameFromSrcId(srcId => $srcCgContactId);

            my $isAssigned = 0;
            foreach (@{$self->{load}->{target}->{cgContactRelation}->{$targetId}}) {
                if ($_ == $contactId) {
                    $isAssigned = 1;
                    last;
                }
            }

            if ($isAssigned == 1) {
                $self->{logger}->writeLogDebug("contact group '" . $name . "': contact '$displayContactName' already linked");
                next;
            }

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'contactgroup_contact_relation',
                name => "$name-$displayContactName",
                entry => {
                    contactgroup_cg_id => $targetId,
                    contact_contact_id => $contactId
                }
            );

            $self->{logger}->writeLogDebug("contact group '" . $name . "': contact '$displayContactName' linked");
        }
    }
}

1;

__END__