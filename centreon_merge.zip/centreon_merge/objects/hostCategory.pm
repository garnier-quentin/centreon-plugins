#!/usr/bin/perl

package objects::hostCategory;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'hostcategories',
        attr_id => 'hc_id',
        attr_name => 'hc_name',
        store => 'hostcategories',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'hostcategories',
        attr_id => 'hc_id',
        attr_name => 'hc_name',
        store => 'hostcategories'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'hostcategories_relation',
        attr_id_key => 'hostcategories_hc_id',
        attr_id_value => 'host_host_id',
        store => 'hcRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'hostcategories_relation',
        attr_id_key => 'hostcategories_hc_id',
        attr_id_value => 'host_host_id',
        store => 'hcRelation',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{hostcategories}->{byID}->{ $options{srcId} }->{hc_name};
    return $self->{load}->{target}->{hostcategories}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{hostcategories}->{byID}->{ $options{srcId} }->{hc_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{hostcategories}->{byID}}) {
        my $name = $self->{load}->{src}->{hostcategories}->{byID}->{$srcId}->{hc_name};

        my ($targetId, $entry); 
        if (defined($self->{load}->{target}->{hostcategories}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("host category '" . $name . "' already exists");
            $targetId = $self->{load}->{target}->{hostcategories}->{byName}->{$name};
        } else {
            my $copy = $self->{load}->{src}->{hostcategories}->{byID}->{$srcId};
            $copy->{icon_id} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{hostcategories}->{byID}->{$srcId}->{icon_id});

            ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'hostcategories',
                name => $name,
                entry => $copy,
                exclude => {
                    hg_id => 1
                }
            );

            $self->{load}->{target}->{hostcategories}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{hostcategories}->{byID}->{$targetId} = $entry;

            $self->{logger}->writeLogInfo("host category '" . $name . "' created");
        }

        foreach my $srcHostId (@{$self->{load}->{src}->{hcRelation}->{$srcId}}) {
            my $hostId = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId);
            my $displayHostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);

            my $isAssigned = 0;
            foreach (@{$self->{load}->{target}->{hcRelation}->{$targetId}}) {
                if ($_ == $hostId) {
                    $isAssigned = 1;
                    last;
                }
            }

            if ($isAssigned == 1) {
                $self->{logger}->writeLogDebug("host category '" . $name . "': host '$displayHostName' already linked");
                next;
            }

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'hostcategories_relation',
                name => "$name-$displayHostName",
                entry => {
                    hostcategories_hc_id => $targetId,
                    host_host_id => $hostId
                }
            );

            $self->{logger}->writeLogDebug("host category '" . $name . "': host '$displayHostName' linked");
        }
    }
}

1;

__END__