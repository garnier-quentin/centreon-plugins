#!/usr/bin/perl

package objects::hostGroup;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'hostgroup',
        attr_id => 'hg_id',
        attr_name => 'hg_name',
        store => 'hostgroup',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'hostgroup',
        attr_id => 'hg_id',
        attr_name => 'hg_name',
        store => 'hostgroup'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'hostgroup_relation',
        attr_id_key => 'hostgroup_hg_id',
        attr_id_value => 'host_host_id',
        store => 'hgRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'hostgroup_relation',
        attr_id_key => 'hostgroup_hg_id',
        attr_id_value => 'host_host_id',
        store => 'hgRelation',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{hostgroup}->{byID}->{ $options{srcId} }->{hg_name};
    return $self->{load}->{target}->{hostgroup}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{hostgroup}->{byID}->{ $options{srcId} }->{hg_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{hostgroup}->{byID}}) {
        my $name = $self->{load}->{src}->{hostgroup}->{byID}->{$srcId}->{hg_name};

        my ($targetId, $entry); 
        if (defined($self->{load}->{target}->{hostgroup}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("host group '" . $name . "' already exists");
            $targetId = $self->{load}->{target}->{hostgroup}->{byName}->{$name};
        } else {
            my $copy = $self->{load}->{src}->{hostgroup}->{byID}->{$srcId};
            $copy->{hg_icon_image} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{hostgroup}->{byID}->{$srcId}->{hg_icon_image});

            ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'hostgroup',
                name => $name,
                entry => $copy,
                exclude => {
                    hg_id => 1
                }
            );

            $self->{load}->{target}->{hostgroup}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{hostgroup}->{byID}->{$targetId} = $entry;

            $self->{logger}->writeLogInfo("host group '" . $name . "' created");
        }

        foreach my $srcHgHostId (@{$self->{load}->{src}->{hgRelation}->{$srcId}}) {
            my $hostId = $options{host}->getTargetIdFromSrcId(srcId => $srcHgHostId);
            my $displayHostName = $options{host}->getNameFromSrcId(srcId => $srcHgHostId);

            my $isAssigned = 0;
            foreach (@{$self->{load}->{target}->{hgRelation}->{$targetId}}) {
                if ($_ == $hostId) {
                    $isAssigned = 1;
                    last;
                }
            }

            if ($isAssigned == 1) {
                $self->{logger}->writeLogDebug("host group '" . $name . "': host '$displayHostName' already linked");
                next;
            }

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'hostgroup_relation',
                name => "$name-$displayHostName",
                entry => {
                    hostgroup_hg_id => $targetId,
                    host_host_id => $hostId
                }
            );

            $self->{logger}->writeLogDebug("host group '" . $name . "': host '$displayHostName' linked");
        }
    }
}

1;

__END__