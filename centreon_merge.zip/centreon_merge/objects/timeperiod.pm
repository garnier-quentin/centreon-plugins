#!/usr/bin/perl

package objects::timeperiod;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'timeperiod',
        attr_id => 'tp_id',
        attr_name => 'tp_name',
        store => 'tp',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'timeperiod',
        attr_id => 'tp_id',
        attr_name => 'tp_name',
        store => 'tp'
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{tp}->{byID}->{ $options{srcId} }->{tp_name};
    return $self->{load}->{target}->{tp}->{byName}->{$srcName};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{tp}->{byID}}) {
        my $name = $self->{load}->{src}->{tp}->{byID}->{$srcId}->{tp_name};
        if (defined($self->{load}->{target}->{tp}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("timeperiod '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'timeperiod',
            name => $name,
            entry => $self->{load}->{src}->{tp}->{byID}->{$srcId},
            exclude => {
                tp_id => 1
            }
        );

        $self->{load}->{target}->{tp}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{tp}->{byID}->{$targetId} = $entry;

        $self->{logger}->writeLogInfo("timeperiod '" . $name . "' created");
    }
}

1;

__END__