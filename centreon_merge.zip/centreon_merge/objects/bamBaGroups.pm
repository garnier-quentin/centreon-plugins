#!/usr/bin/perl

package objects::bamBaGroups;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_ba_groups',
        attr_id => 'id_ba_group',
        attr_name => 'ba_group_name',
        store => 'bamBaGroups',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'mod_bam_ba_groups',
        attr_id => 'id_ba_group',
        attr_name => 'ba_group_name',
        store => 'bamBaGroups'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_acl',
        attr_id_key => 'ba_group_id',
        store => 'bamAcl',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_acl',
    #    attr_id_key => 'ba_group_id',
    #    store => 'bamAcl',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{load}->{src}->{bamBaGroups}->{byID}->{ $options{srcId} }));

    my $srcName = $self->{load}->{src}->{bamBaGroups}->{byID}->{ $options{srcId} }->{ba_group_name};
    return $self->{load}->{target}->{bamBaGroups}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{bamBaGroups}->{byID}->{ $options{srcId} }->{ba_group_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{bamBaGroups}->{byID}}) {
        my $name = $self->{load}->{src}->{bamBaGroups}->{byID}->{$srcId}->{ba_group_name};
        if (defined($self->{load}->{target}->{bamBaGroups}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("bam ba group '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'mod_bam_ba_groups',
            name => $name,
            entry => $self->{load}->{src}->{bamBaGroups}->{byID}->{$srcId},
            exclude => {
                id_ba_group => 1
            }
        );

        $self->{load}->{target}->{bamBaGroups}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{bamBaGroups}->{byID}->{$targetId} = $entry;

        # bam ACL relations
        foreach my $data (@{$self->{load}->{src}->{bamAcl}->{$srcId}}) {
            my $aclGroupId = $options{aclGroup}->getTargetIdFromSrcId(srcId => $data->{acl_group_id});
            my $displayAclGroupName = $options{aclGroup}->getNameFromSrcId(srcId => $data->{acl_group_id});

            $data->{ba_group_id} = $targetId;
            $data->{acl_group_id} = $aclGroupId;

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_acl',
                name => "$name-$displayAclGroupName",
                entry => $data,
                exclude => {
                    acl_ba_id => 1,
                    all_business_views => 1 # 25.10.x
                }
            );

            $self->{logger}->writeLogDebug("bam ba group '" . $name . "': acl group '$displayAclGroupName' linked");
        }

        $self->{logger}->writeLogInfo("bam ba group '" . $name . "' created");
    }
}

1;

__END__