#!/usr/bin/perl

package objects::ldap;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'auth_ressource',
        attr_id => 'ar_id',
        attr_name => 'ar_name',
        store => 'authResource',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'auth_ressource',
        attr_id => 'ar_id',
        attr_name => 'ar_name',
        store => 'authResource'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'auth_ressource_host',
        attr_id_key => 'auth_ressource_id',
        store => 'authRessourceHost',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'auth_ressource_host',
        attr_id_key => 'auth_ressource_id',
        store => 'authRessourceHost',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'auth_ressource_info',
        attr_id_key => 'ar_id',
        store => 'authRessourceInfo',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'auth_ressource_info',
        attr_id_key => 'ar_id',
        store => 'authRessourceInfo',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{authResource}->{byID}->{ $options{srcId} }->{ar_name};
    return $self->{load}->{target}->{authResource}->{byName}->{$srcName};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{authResource}->{byID}}) {
        my $name = $self->{load}->{src}->{authResource}->{byID}->{$srcId}->{ar_name};
        if (defined($self->{load}->{target}->{authResource}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("ldap '" . $name . "' already exists");
            next;
        }

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'auth_ressource',
            name => $name,
            entry => $self->{load}->{src}->{authResource}->{byID}->{$srcId},
            exclude => {
                ar_id => 1
            }
        );

        $self->{load}->{target}->{authResource}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{authResource}->{byID}->{$targetId} = $entry;

        # auth resource host relation
        foreach my $data (@{$self->{load}->{src}->{authRessourceHost}->{$srcId}}) {
            $data->{auth_ressource_id} = $targetId;
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'auth_ressource_host',
                name => $data->{host_address},
                entry => $data,
                exclude => {
                    ldap_host_id => 1
                }
            );
        }

        # auth resource info relation
        foreach my $data (@{$self->{load}->{src}->{authRessourceInfo}->{$srcId}}) {
            $data->{ar_id} = $targetId;
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'auth_ressource_info',
                name => $data->{ari_name},
                entry => $data
            );
        }

        $self->{logger}->writeLogInfo("ldap '" . $name . "' created");
    }
}

1;

__END__