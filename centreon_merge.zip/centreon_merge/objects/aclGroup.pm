#!/usr/bin/perl

package objects::aclGroup;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_groups',
        attr_id => 'acl_group_id',
        attr_name => 'acl_group_name',
        store => 'aclGroup',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'acl_groups',
        attr_id => 'acl_group_id',
        attr_name => 'acl_group_name',
        store => 'aclGroup'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_group_contacts_relations',
        attr_id_key => 'acl_group_id',
        attr_id_value => 'contact_contact_id',
        store => 'aclGroupContactRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_group_contacts_relations',
    #    attr_id_key => 'acl_group_id',
    #    attr_id_value => 'contact_contact_id',
    #    store => 'aclGroupContactRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_group_contactgroups_relations',
        attr_id_key => 'acl_group_id',
        attr_id_value => 'cg_cg_id',
        store => 'aclGroupCgRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_group_contactgroups_relations',
    #    attr_id_key => 'acl_group_id',
    #    attr_id_value => 'cg_cg_id',
    #    store => 'aclGroupCgRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_group_actions_relations',
        attr_id_key => 'acl_group_id',
        attr_id_value => 'acl_action_id',
        store => 'aclGroupActionRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_group_actions_relations',
    #    attr_id_key => 'acl_group_id',
    #    attr_id_value => 'acl_action_id',
    #    store => 'aclGroupActionRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_group_topology_relations',
        attr_id_key => 'acl_group_id',
        attr_id_value => 'acl_topology_id',
        store => 'aclGroupTopologyRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_group_topology_relations',
    #    attr_id_key => 'acl_group_id',
    #    attr_id_value => 'acl_topology_id',
    #    store => 'aclGroupTopologyRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'acl_res_group_relations',
        attr_id_key => 'acl_group_id',
        attr_id_value => 'acl_res_id',
        store => 'aclGroupResourceRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'acl_res_group_relations',
    #    attr_id_key => 'acl_group_id',
    #    attr_id_value => 'acl_res_id',
    #    store => 'aclGroupResourceRelation',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{aclGroup}->{byID}->{ $options{srcId} }->{acl_group_name};
    return $self->{load}->{target}->{aclGroup}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{aclGroup}->{byID}->{ $options{srcId} }->{acl_group_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{aclGroup}->{byID}}) {
        my $name = $self->{load}->{src}->{aclGroup}->{byID}->{$srcId}->{acl_group_name};

        if (defined($self->{load}->{target}->{aclGroup}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("acl group '" . $name . "' already exists");
            next;
        }
        
        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'acl_groups',
            name => $name,
            entry => $self->{load}->{src}->{aclGroup}->{byID}->{$srcId},
            exclude => {
                acl_group_id => 1
            }
        );

        $self->{load}->{target}->{aclGroup}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{aclGroup}->{byID}->{$targetId} = $entry;
 
        # contact relations
        foreach my $srcContactId (@{$self->{load}->{src}->{aclGroupContactRelation}->{$srcId}}) {
            my $contactId = $options{contact}->getTargetIdFromSrcId(srcId => $srcContactId);
            my $displayContactName = $options{contact}->getNameFromSrcId(srcId => $srcContactId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_group_contacts_relations',
                name => "$name-$displayContactName",
                entry => {
                    acl_group_id => $targetId,
                    contact_contact_id => $contactId
                }
            );

            $self->{logger}->writeLogDebug("acl group '" . $name . "': contact '$displayContactName' linked");
        }

        # contact group relations
        foreach my $srcCgId (@{$self->{load}->{src}->{aclGroupCgRelation}->{$srcId}}) {
            my $cgId = $options{contactGroup}->getTargetIdFromSrcId(srcId => $srcCgId);
            my $displayCgName = $options{contactGroup}->getNameFromSrcId(srcId => $srcCgId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_group_contactgroups_relations',
                name => "$name-$displayCgName",
                entry => {
                    acl_group_id => $targetId,
                    cg_cg_id => $cgId
                }
            );

            $self->{logger}->writeLogDebug("acl group '" . $name . "': contact group '$displayCgName' linked");
        }

        # acl action relations
        foreach my $srcAclActionId (@{$self->{load}->{src}->{aclGroupActionRelation}->{$srcId}}) {
            my $aclActionId = $options{aclAction}->getTargetIdFromSrcId(srcId => $srcAclActionId);
            my $displayAclActionName = $options{aclAction}->getNameFromSrcId(srcId => $srcAclActionId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_group_actions_relations',
                name => "$name-$displayAclActionName",
                entry => {
                    acl_group_id => $targetId,
                    acl_action_id => $aclActionId
                }
            );

            $self->{logger}->writeLogDebug("acl group '" . $name . "': acl action '$displayAclActionName' linked");
        }
 
        # acl menu relations
        foreach my $srcAclMenuId (@{$self->{load}->{src}->{aclGroupTopologyRelation}->{$srcId}}) {
            my $aclMenuId = $options{aclMenu}->getTargetIdFromSrcId(srcId => $srcAclMenuId);
            my $displayAclMenuName = $options{aclMenu}->getNameFromSrcId(srcId => $srcAclMenuId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_group_topology_relations',
                name => "$name-$displayAclMenuName",
                entry => {
                    acl_group_id => $targetId,
                    acl_topology_id => $aclMenuId
                }
            );

            $self->{logger}->writeLogDebug("acl group '" . $name . "': acl menu '$displayAclMenuName' linked");
        }

        # acl resource relations
        foreach my $srcAclResourceId (@{$self->{load}->{src}->{aclGroupResourceRelation}->{$srcId}}) {
            my $aclResourceId = $options{aclResource}->getTargetIdFromSrcId(srcId => $srcAclResourceId);
            my $displayAclResourceName = $options{aclResource}->getNameFromSrcId(srcId => $srcAclResourceId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'acl_res_group_relations',
                name => "$name-$displayAclResourceName",
                entry => {
                    acl_group_id => $targetId,
                    acl_res_id => $aclResourceId
                }
            );

            $self->{logger}->writeLogDebug("acl group '" . $name . "': acl resource '$displayAclResourceName' linked");
        }

        $self->{logger}->writeLogInfo("acl group '" . $name . "' created");
    }
}

1;

__END__