#!/usr/bin/perl

package objects::bamBa;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam',
        attr_id => 'ba_id',
        attr_name => 'name',
        store => 'bam',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'mod_bam',
        attr_id => 'ba_id',
        attr_name => 'name',
        store => 'bam'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_cg_relation',
        attr_id_key => 'id_ba',
        attr_id_value => 'id_cg',
        store => 'bamCgRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_cg_relation',
    #    attr_id_key => 'id_ba',
    #    attr_id_value => 'id_cg',
    #    store => 'bamCgRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_bagroup_ba_relation',
        attr_id_key => 'id_ba',
        attr_id_value => 'id_ba_group',
        store => 'bamBaGroupRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_bagroup_ba_relation',
    #    attr_id_key => 'id_ba',
    #    attr_id_value => 'id_ba_group',
    #    store => 'bamBaGroupRelation',
    #    multiple => 1
    #);

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        store => 'service',
        where => "service_register = '2'",
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        where => "service_register = '2'",
        store => 'service'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_poller_relations',
        attr_id_key => 'ba_id',
        attr_id_value => 'poller_id',
        store => 'bamPollerRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_poller_relations',
    #    attr_id_key => 'ba_id',
    #    attr_id_value => 'poller_id',
    #    store => 'bamPollerRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'mod_bam_relations_ba_timeperiods',
        attr_id_key => 'ba_id',
        attr_id_value => 'tp_id',
        store => 'bamTpRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'mod_bam_relations_ba_timeperiods',
    #    attr_id_key => 'ba_id',
    #    attr_id_value => 'tp_id',
    #    store => 'bamTpRelation',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{load}->{src}->{bam}->{byID}->{ $options{srcId} }));

    my $srcName = $self->{load}->{src}->{bam}->{byID}->{ $options{srcId} }->{name};
    return $self->{load}->{target}->{bam}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{bam}->{byID}->{ $options{srcId} }->{name};
}

sub isBaCreated {
    my ($self, %options) = @_;

    return 1 if (defined($self->{baCreated}->{ $options{srcBaId} }));
    
    return 0;
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    $self->{baCreated} = {};
 
    foreach my $srcId (keys %{$self->{load}->{src}->{bam}->{byID}}) {
        my $name = $self->{load}->{src}->{bam}->{byID}->{$srcId}->{name};
        if (defined($self->{load}->{target}->{bam}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("bam ba '" . $name . "' already exists");

            $options{service}->addMappingHostService(
                srcHostId => $options{host}->getSrcIdFromName(name => '_Module_BAM_1'),
                srcServiceId =>  $self->{load}->{src}->{service}->{byName}->{'ba_' . $srcId},
                targetHostId => $options{host}->getTargetIdFromName(name => '_Module_BAM_1'),
                targetServiceId => $self->{load}->{target}->{service}->{byName}->{'ba_' . $self->{load}->{target}->{bam}->{byName}->{$name}  },
            );

            next;
        }

        my $copy = $self->{load}->{src}->{bam}->{byID}->{$srcId};
        $copy->{id_notification_period} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{bam}->{byID}->{$srcId}->{id_notification_period});
        $copy->{id_reporting_period} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{bam}->{byID}->{$srcId}->{id_reporting_period});
        $copy->{icon_id} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{bam}->{byID}->{$srcId}->{icon_id});
        $copy->{event_handler_command} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{bam}->{byID}->{$srcId}->{event_handler_command});

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'mod_bam',
            name => $name,
            entry => $copy,
            exclude => {
                ba_id => 1
            }
        );

        $self->{load}->{target}->{bam}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{bam}->{byID}->{$targetId} = $entry;

        # contact group relations
        foreach my $srcCgId (@{$self->{load}->{src}->{bamCgRelation}->{$srcId}}) {
            my $cgId = $options{contactGroup}->getTargetIdFromSrcId(srcId => $srcCgId);
            my $displayCgName = $options{contactGroup}->getNameFromSrcId(srcId => $srcCgId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_cg_relation',
                name => "$name-$displayCgName",
                entry => {
                    id_ba => $targetId,
                    id_cg => $cgId
                }
            );

            $self->{logger}->writeLogDebug("bam ba '" . $name . "': contact group '$displayCgName' linked");
        }

        # ba group relations
        foreach my $srcBaGroupId (@{$self->{load}->{src}->{bamBaGroupRelation}->{$srcId}}) {
            my $baGroupId = $options{bamBaGroups}->getTargetIdFromSrcId(srcId => $srcBaGroupId);
            my $displayBaGroupName = $options{bamBaGroups}->getNameFromSrcId(srcId => $srcBaGroupId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_bagroup_ba_relation',
                name => "$name-$displayBaGroupName",
                entry => {
                    id_ba => $targetId,
                    id_ba_group => $baGroupId
                }
            );

            $self->{logger}->writeLogDebug("bam ba '" . $name . "': ba group '$displayBaGroupName' linked");
        }

        # poller relations
        foreach my $srcPollerId (@{$self->{load}->{src}->{bamPollerRelation}->{$srcId}}) {
            my $targetPollerId = $options{host}->getTargetPollerIdFromSrcId(srcId => $srcPollerId);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_poller_relations',
                name => "$name-$targetPollerId",
                entry => {
                    poller_id => $targetPollerId,
                    ba_id => $targetId
                }
            );
        }

        # bam timeperiod extra relations
        foreach my $srcBamTpID (@{$self->{load}->{src}->{bamTpRelation}->{$srcId}}) {
            my $tpId = $options{timeperiod}->getTargetIdFromSrcId(srcId => $srcBamTpID);
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'mod_bam_relations_ba_timeperiods',
                name => "$targetId-$tpId",
                entry => {
                    ba_id => $targetId,
                    tp_id => $tpId
                }
            );
        }

        # insert table service
        my ($targetIdService, $entryService) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'service',
            name => $name . '-service',
            entry => {
                service_description => 'ba_' . $targetId,
                service_register => 2,
                service_activate => 1
            }
        );

        # service host relations
        my $hostId = $options{host}->getTargetIdFromName(name => '_Module_BAM_1');
        $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'host_service_relation',
            name => "_Module_BAM_1-$name",
            entry => {
                host_host_id => $hostId,
                service_service_id => $targetIdService
            }
        );

        $options{service}->addMappingHostService(
            srcHostId => $options{host}->getSrcIdFromName(name => '_Module_BAM_1'),
            srcServiceId =>  $self->{load}->{src}->{service}->{byName}->{'ba_' . $targetId},
            targetHostId => $hostId,
            targetServiceId => $targetIdService
        );

        $self->{baCreated}->{$srcId} = 1;
        $self->{logger}->writeLogInfo("bam ba '" . $name . "' created");
    }
}

1;

__END__