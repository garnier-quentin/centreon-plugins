#!/usr/bin/perl

package objects::serviceTpl;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        store => 'service',
        where => "service_register = '0'",
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'service',
        attr_id => 'service_id',
        attr_name => 'service_description',
        where => "service_register = '0'",
        store => 'service'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'extended_service_information',
        attr_id_key => 'service_service_id',
        store => 'serviceExtended'
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'extended_service_information',
        attr_id_key => 'service_service_id',
        store => 'serviceExtended'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_service',
        attr_id_key => 'svc_svc_id',
        store => 'serviceMacro',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'on_demand_macro_service',
        attr_id_key => 'svc_svc_id',
        store => 'serviceMacro',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contact_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contact_id',
        store => 'contactServiceRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contact_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contact_id',
        store => 'contactServiceRelation',
        multiple => 1
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'contactgroup_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpServiceRelation',
        multiple => 1
    );
    $self->loadTableRelation(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'contactgroup_service_relation',
        attr_id_key => 'service_service_id',
        attr_id_value => 'contactgroup_cg_id',
        store => 'contactGrpServiceRelation',
        multiple => 1
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}) || !defined($self->{load}->{src}->{service}->{byID}->{ $options{srcId} }));

    my $srcName = $self->{load}->{src}->{service}->{byID}->{ $options{srcId} }->{service_description};
    return $self->{load}->{target}->{service}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{service}->{byID}->{ $options{srcId} }->{service_description};
}

sub merge {
    my ($self, %options) = @_;

    $self->load();

    my $checked = {};
    my @browseID = (values %{$self->{load}->{src}->{service}->{byName}});
    while ((my $currentID = shift(@browseID))) {
        my $loop = {};
        my @tmpBrowseID = ($currentID);
        while (scalar(@tmpBrowseID) > 0) {
            if (!defined($loop->{ $tmpBrowseID[0] }) && !defined($checked->{ $tmpBrowseID[0] }) && defined($self->{load}->{src}->{service}->{byID}->{ $tmpBrowseID[0] }->{service_template_model_stm_id})) {
                $loop->{ $tmpBrowseID[0] } = 1;
                unshift(@tmpBrowseID, $self->{load}->{src}->{service}->{byID}->{ $tmpBrowseID[0] }->{service_template_model_stm_id});
                next;
            }

            my $srcId = shift(@tmpBrowseID);
            next if (defined($checked->{$srcId}));
            $checked->{ $srcId } = 1;

            my $name = $self->{load}->{src}->{service}->{byID}->{$srcId}->{service_description};
            if (defined($self->{load}->{target}->{service}->{byName}->{$name})) {
                $self->{logger}->writeLogInfo("service template '" . $name . "' already exists");
                next;
            }

            my $copy = $self->{load}->{src}->{service}->{byID}->{$srcId};
            $copy->{timeperiod_tp_id} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcId}->{timeperiod_tp_id});
            $copy->{timeperiod_tp_id2} = $options{timeperiod}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcId}->{timeperiod_tp_id2});
            $copy->{command_command_id} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcId}->{command_command_id});
            $copy->{command_command_id2} = $options{command}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcId}->{command_command_id2});
            $copy->{service_template_model_stm_id} = $self->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{service}->{byID}->{$srcId}->{service_template_model_stm_id});

            my ($targetId, $entry) = $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'service',
                name => $name,
                entry => $copy,
                exclude => {
                    service_id => 1
                }
            );

            $self->{load}->{target}->{service}->{byName}->{$name} = $targetId;
            $self->{load}->{target}->{service}->{byID}->{$targetId} = $entry;

            # extended service
            $copy = $self->{load}->{src}->{serviceExtended}->{$srcId};
            $copy->{service_service_id} = $targetId;
            $copy->{esi_icon_image} = $options{media}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{serviceExtended}->{$srcId}->{esi_icon_image});

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'extended_service_information',
                name => $name,
                entry => $copy,
                exclude => {
                    esi_id => 1
                }
            );

            # contact relations
            foreach my $srcContactId (@{$self->{load}->{src}->{contactServiceRelation}->{$srcId}}) {
                my $contactId = $options{contact}->getTargetIdFromSrcId(srcId => $srcContactId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contact_service_relation',
                    name => "$targetId-$contactId",
                    entry => {
                        service_service_id => $targetId,
                        contact_id => $contactId
                    }
                );
            }

            # contact group relations
            foreach my $srcCgId (@{$self->{load}->{src}->{contactGrpServiceRelation}->{$srcId}}) {
                my $cgId = $options{contactGroup}->getTargetIdFromSrcId(srcId => $srcCgId);
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'contactgroup_service_relation',
                    name => "$targetId-$cgId",
                    entry => {
                        service_service_id => $targetId,
                        contactgroup_cg_id => $cgId
                    }
                );
            }
 
            # host macro relations
            foreach my $data (@{$self->{load}->{src}->{serviceMacro}->{$srcId}}) {
                $data->{svc_svc_id} = $targetId;
                $self->insertTable(
                    instance => 'target',
                    db_name => 'centreon',
                    tbl_name => 'on_demand_macro_service',
                    name => "$targetId-" . $data->{svc_macro_name},
                    entry => $data,
                    exclude => {
                        svc_macro_id => 1
                    }
                );
            }

            $self->{logger}->writeLogInfo("service template '" . $name . "' created");
        }
    }
}

1;

__END__