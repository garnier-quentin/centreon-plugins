#!/usr/bin/perl

package objects::command;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'command',
        attr_id => 'command_id',
        attr_name => 'command_name',
        store => 'command',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'command',
        attr_id => 'command_id',
        attr_name => 'command_name',
        store => 'command'
    );
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{command}->{byID}->{ $options{srcId} }->{command_name};
    return $self->{load}->{target}->{command}->{byName}->{$srcName};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{command}->{byID}}) {
        my $name = $self->{load}->{src}->{command}->{byID}->{$srcId}->{command_name};
        if (defined($self->{load}->{target}->{command}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("command '" . $name . "' already exists");
            next;
        }

        my $copy = $self->{load}->{src}->{command}->{byID}->{$srcId};
        $copy->{connector_id} = $options{connector}->getTargetIdFromSrcId(srcId => $self->{load}->{src}->{command}->{byID}->{$srcId}->{connector_id});

        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'command',
            name => $name,
            entry => $copy,
            exclude => {
                command_id => 1,
                graph_id => 1 # unsupported
            }
        );

        $self->{load}->{target}->{command}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{command}->{byID}->{$targetId} = $entry;

        $self->{logger}->writeLogInfo("command '" . $name . "' created");
    }
}

1;

__END__