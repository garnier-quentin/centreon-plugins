#!/usr/bin/perl

package objects::downtime;

use strict;
use warnings;
use Data::Dumper;

use base qw(objects::root);

sub new {
    my ($class, %options) = @_;
    my $self = $class->SUPER::new(%options);

    $self->{prefix} = 'CERTIGNA-';

    bless $self, $class;
    return $self;
}

sub load {
    my ($self, %options) = @_;

    $self->loadTable(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime',
        attr_id => 'dt_id',
        attr_name => 'dt_name',
        store => 'downtime',
        prefix => 1
    );
    $self->loadTable(
        instance => 'target',
        db_name => 'centreon',
        tbl_name => 'downtime',
        attr_id => 'dt_id',
        attr_name => 'dt_name',
        store => 'downtime'
    );

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime_period',
        attr_id_key => 'dt_id',
        store => 'dtPeriod',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'downtime_period',
    #    attr_id_key => 'dt_id',
    #    store => 'dtPeriod',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime_host_relation',
        attr_id_key => 'dt_id',
        attr_id_value => 'host_host_id',
        store => 'dtHostRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'downtime_host_relation',
    #    attr_id_key => 'dt_id',
    #    attr_id_value => 'host_host_id',
    #    store => 'dtHostRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime_hostgroup_relation',
        attr_id_key => 'dt_id',
        attr_id_value => 'hg_hg_id',
        store => 'dtHgRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'downtime_hostgroup_relation',
    #    attr_id_key => 'dt_id',
    #    attr_id_value => 'hg_hg_id',
    #    store => 'dtHgRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime_servicegroup_relation',
        attr_id_key => 'dt_id',
        attr_id_value => 'sg_sg_id',
        store => 'dtSgRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'downtime_servicegroup_relation',
    #    attr_id_key => 'dt_id',
    #    attr_id_value => 'sg_sg_id',
    #    store => 'dtSgRelation',
    #    multiple => 1
    #);

    $self->loadTableRelation(
        instance => 'src',
        db_name => 'centreon',
        tbl_name => 'downtime_service_relation',
        attr_id_key => 'dt_id',
        store => 'dtServiceRelation',
        multiple => 1
    );
    #$self->loadTableRelation(
    #    instance => 'target',
    #    db_name => 'centreon',
    #    tbl_name => 'downtime_service_relation',
    #    attr_id_key => 'dt_id',
    #    store => 'dtServiceRelation',
    #    multiple => 1
    #);
}

sub getTargetIdFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    my $srcName = $self->{load}->{src}->{downtime}->{byID}->{ $options{srcId} }->{dt_name};
    return $self->{load}->{target}->{downtime}->{byName}->{$srcName};
}

sub getNameFromSrcId {
    my ($self, %options) = @_;

    return undef if (!defined($options{srcId}));

    return $self->{load}->{src}->{downtime}->{byID}->{ $options{srcId} }->{dt_name};
}

sub merge {
    my ($self, %options) = @_;
    
    $self->load();

    foreach my $srcId (keys %{$self->{load}->{src}->{downtime}->{byID}}) {
        my $name = $self->{load}->{src}->{downtime}->{byID}->{$srcId}->{dt_name};

        if (defined($self->{load}->{target}->{downtime}->{byName}->{$name})) {
            $self->{logger}->writeLogInfo("downtime '" . $name . "' already exists");
            next;
        }
        
        my ($targetId, $entry) = $self->insertTable(
            instance => 'target',
            db_name => 'centreon',
            tbl_name => 'downtime',
            name => $name,
            entry => $self->{load}->{src}->{downtime}->{byID}->{$srcId},
            exclude => {
                dt_id => 1
            }
        );

        $self->{load}->{target}->{downtime}->{byName}->{$name} = $targetId;
        $self->{load}->{target}->{downtime}->{byID}->{$targetId} = $entry;
 
        # dt period relation
        foreach my $data (@{$self->{load}->{src}->{dtPeriod}->{$srcId}}) {
            $data->{dt_id} = $targetId;
            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'downtime_period',
                name => 'dt-period',
                entry => $data
            );
        }

        # host relations
        foreach my $srcHostId (@{$self->{load}->{src}->{dtHostRelation}->{$srcId}}) {
            my $hostId = $options{host}->getTargetIdFromSrcId(srcId => $srcHostId);
            my $displayHostName = $options{host}->getNameFromSrcId(srcId => $srcHostId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'downtime_host_relation',
                name => "$name-$displayHostName",
                entry => {
                    dt_id => $targetId,
                    host_host_id => $hostId
                }
            );

            $self->{logger}->writeLogDebug("downtime '" . $name . "': host '$displayHostName' linked");
        }

        # host group relations
        foreach my $srcHgId (@{$self->{load}->{src}->{dtHgRelation}->{$srcId}}) {
            my $hgId = $options{hostGroup}->getTargetIdFromSrcId(srcId => $srcHgId);
            my $displayHgName = $options{hostGroup}->getNameFromSrcId(srcId => $srcHgId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'downtime_hostgroup_relation',
                name => "$name-$displayHgName",
                entry => {
                    dt_id => $targetId,
                    hg_hg_id => $hgId
                }
            );

            $self->{logger}->writeLogDebug("downtime '" . $name . "': host group '$displayHgName' linked");
        }

        # service group relations
        foreach my $srcSgId (@{$self->{load}->{src}->{dtSgRelation}->{$srcId}}) {
            my $sgId = $options{serviceGroup}->getTargetIdFromSrcId(srcId => $srcSgId);
            my $displaySgName = $options{serviceGroup}->getNameFromSrcId(srcId => $srcSgId);

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'downtime_servicegroup_relation',
                name => "$name-$displaySgName",
                entry => {
                    dt_id => $targetId,
                    sg_sg_id => $sgId
                }
            );

            $self->{logger}->writeLogDebug("downtime '" . $name . "': service group '$displaySgName' linked");
        }

        # service relations
        foreach my $data (@{$self->{load}->{src}->{dtServiceRelation}->{$srcId}}) {
            my ($hostId, $serviceId) = $options{service}->getTargetHostServiceFromSrc(srcHostId => $data->{host_host_id}, srcServiceId => $data->{service_service_id});
            my $displayHostName = $options{host}->getNameFromSrcId(srcId => $data->{host_host_id});
            my $displayServiceName = $options{service}->getNameFromSrcId(srcId => $data->{service_service_id});

            $self->insertTable(
                instance => 'target',
                db_name => 'centreon',
                tbl_name => 'downtime_service_relation',
                name => "$name-$displayHostName-$displayServiceName",
                entry => {
                    dt_id => $targetId,
                    host_host_id => $hostId,
                    service_service_id => $serviceId
                }
            );

            $self->{logger}->writeLogDebug("downtime '" . $name . "': service '$displayHostName - $displayServiceName' linked");
        }

        $self->{logger}->writeLogInfo("downtime '" . $name . "' created");
    }
}

1;

__END__