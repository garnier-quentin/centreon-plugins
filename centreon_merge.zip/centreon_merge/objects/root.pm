#!/usr/bin/perl

package objects::root;

use strict;
use warnings;

use JSON::XS;

sub new {
    my ($class, %options) = @_;
    my $self  = {};
    bless $self, $class;

    $self->{logger} = $options{logger};
    $self->{db} = $options{db};

    $self->{prefix} = ''; # example CLIENT_NAME-
    $self->{load} = { src => {} , dst => {} };

    return $self;
}

sub loadTable {
    my ($self, %options) = @_;

    my $prefix = 0;
    $prefix = 1 if (defined($options{prefix}) && $options{prefix} == 1 && $self->{prefix} ne '');

    my $where = '';
    $where = ' WHERE ' . $options{where} if (defined($options{where}));

    my ($status, $sth) = $self->{db}->{ $options{instance} }->{ $options{db_name} }->query(
        "SELECT * FROM " . $options{tbl_name} . $where
    );
    if ($status == -1) {
        $self->{logger}->writeLogError("cannot list table '" . $options{tbl_name} . "'");
        exit 1;
    }

    $self->{load}->{ $options{instance} }->{ $options{store} } = {};
    $self->{load}->{ $options{instance} }->{ $options{store} }->{byID} = {};
    $self->{load}->{ $options{instance} }->{ $options{store} }->{byName} = {};

    my $rows = [];
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $sth->fetchall_arrayref({},5000)||[]})
        )
    ) {
        $row->{ $options{attr_name} } = $self->{prefix} . $row->{ $options{attr_name} }
            if ($prefix == 1);
 
        $self->{load}->{ $options{instance} }->{ $options{store} }->{byID}->{ $row->{ $options{attr_id} } } = $row;
        $self->{load}->{ $options{instance} }->{ $options{store} }->{byName}->{ $row->{ $options{attr_name} } } = $row->{ $options{attr_id} };
    }
}

sub loadTableRelation {
    my ($self, %options) = @_;

    my $multiple = 0;
    $multiple = 1 if (defined($options{multiple}) && $options{multiple} == 1);

    my ($status, $sth) = $self->{db}->{ $options{instance} }->{ $options{db_name} }->query(
        "SELECT * FROM " . $options{tbl_name}
    );
    if ($status == -1) {
        $self->{logger}->writeLogError("cannot list table '" . $options{tbl_name} . "'");
        exit 1;
    }

    $self->{load}->{ $options{instance} }->{ $options{store} } = {};

    my $rows = [];
    while (my $row = (
        shift(@$rows) ||
        shift(@{$rows = $sth->fetchall_arrayref({},5000)||[]})
        )
    ) {
        if ($multiple == 1) {
            if (!defined($self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } })) {
                $self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } } = [];
            }
            
            if (defined($options{attr_id_value})) {
                push @{$self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } }}, $row->{ $options{attr_id_value} };
            } else {
                push @{$self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } }}, { %$row };
            }
        } else {
            if (defined($options{attr_id_value})) {
                $self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } } = $row->{ $options{attr_id_value} };
            } else {
                $self->{load}->{ $options{instance} }->{ $options{store} }->{ $row->{ $options{attr_id_key} } } = { %$row };
            }
        }
    }
}

sub get_query_datas {
    my ($self, %options) = @_;

    my $entry = {};
    my $query_attrs = '';
    my $query_values = '';
    my $query_append = '';
    foreach my $attr (keys %{$options{entry}}) {
        next if (defined($options{exclude}) && defined($options{exclude}->{$attr}));
        next if (defined($options{include}) && !defined($options{include}->{$attr}));

        $entry->{$attr} = $options{entry}->{$attr};
        $query_attrs .= $query_append . '`' . $attr . '`';
        if (!defined($options{entry}->{$attr})) {
            $query_values .= $query_append . 'NULL';
        } else {
            if (defined($options{enum}) && defined($options{enum}->{$attr}) && $options{entry}->{$attr} eq '') {
                 $options{entry}->{$attr} = $options{enum}->{$attr};
            }
            $query_values .= $query_append . $options{db}->quote($options{entry}->{$attr});
        }
        $query_append = ', ';
    }

    return ($query_attrs, $query_values, $entry);
}

sub get_query_datas_multiple {
    my ($self, %options) = @_;

    my $first = 0;
    my $query_attrs = '';
    my $query_all_values = '';
    my $query_all_append = '';
    foreach my $entry (@{$options{entries}}) {
        my $query_append = '';
        my $query_values = '';
        foreach my $attr (sort keys %$entry) {
            next if (defined($options{exclude}) && defined($options{exclude}->{$attr}));
            next if (defined($options{include}) && !defined($options{include}->{$attr}));

            $query_attrs .= $query_append . '`' . $attr . '`' if ($first == 0);
            if (!defined($entry->{$attr})) {
                $query_values .= $query_append . 'NULL';
            } else {
                if (defined($options{enum}) && defined($options{enum}->{$attr}) && $entry->{$attr} eq '') {
                     $entry->{$attr} = $options{enum}->{$attr};
                }
                $query_values .= $query_append . $options{db}->quote($entry->{$attr});
            }
            $query_append = ', ';
        }
 
        $query_all_values .= $query_all_append . '(' . $query_values . ')';
        $query_all_append = ', ';
        $first = 1;
    }

    return ($query_attrs, $query_all_values);
}

sub insertTable {
    my ($self, %options) = @_;

    my ($query_attrs, $query_values, $entry) = $self->get_query_datas(
        db => $self->{db}->{ $options{instance} }->{ $options{db_name} },
        entry => $options{entry},
        exclude => $options{exclude}
    );
    my ($status, $sth) = $self->{db}->{ $options{instance} }->{ $options{db_name} }->query(
        "INSERT INTO $options{tbl_name} (" . $query_attrs . ") VALUES (" . $query_values . ")"
    );
    if ($status == -1) {
        $self->{logger}->writeLogError("cannot insert $options{tbl_name} object '" . $options{name} . "'");
        exit(1);
    }
    
    return ($self->{db}->{ $options{instance} }->{ $options{db_name} }->last_insert_id(), $entry);
}

sub getRowsChunck {
    my ($self, %options) = @_;

    my $where = '';
    $where = ' WHERE ' . $options{where} if (defined($options{where}));

    my $sth = 'sth' . $options{requestId};
    if (!defined($self->{$sth})) {
        my ($status);
        ($status, $self->{$sth}) = $self->{db}->{ $options{instance} }->{ $options{db_name} }->query(
            "SELECT * FROM " . $options{tbl_name} . $where
        );
        if ($status == -1) {
            $self->{logger}->writeLogError("cannot list table '" . $options{tbl_name} . "'");
            exit 1;
        }
    }

    return $self->{$sth}->fetchall_arrayref({},50000)||[];
}

sub addRowMultiple {
    my ($self, %options) = @_;

    my $id = 'bulkInsert' . $options{requestId};
    if (!defined($self->{$id})) {
        $self->{$id} = [];
        if (!defined($self->{'rowInsert' . $options{requestId}})) {
            $self->{'rowInsert' . $options{requestId}} = 0;
        }
    }

    if (defined($options{entry})) {
        push @{$self->{$id}}, $options{entry};
        $self->{'rowInsert' . $options{requestId}}++;
    }

    return if (scalar(@{$self->{$id}}) <= 0);

    if (defined($options{force}) || scalar(@{$self->{$id}}) >= $options{bulkInsert}) {
        my ($query_attrs, $query_values) = $self->get_query_datas_multiple(
            db => $self->{db}->{ $options{instance} }->{ $options{db_name} },
            entries => $self->{$id},
            exclude => $options{exclude}
        );

        my ($status, $sth) = $self->{db}->{ $options{instance} }->{ $options{db_name} }->query(
            "INSERT INTO $options{tbl_name} (" . $query_attrs . ") VALUES " . $query_values
        );
        if ($status == -1) {
            $self->{logger}->writeLogError("cannot insert into '$options{tbl_name}'");
            exit(1);
        }

        $self->{$id} = [];
    }
}

sub getNumberRowsInsert {
    my ($self, %options) = @_;

    return $self->{'rowInsert' . $options{requestId}};
}

sub writeFile {
    my ($self, %options) = @_;

    my $data;
    eval {
        $data = JSON::XS->new->utf8->encode($options{value});
    };
    if ($@) {
        $self->{logger}->writeLogError("cannot encode json: $@");
        exit(1);
    }

    my $file;
    my $filename = $options{filename};
    if (!open($file, '>', $filename)) {
        $self->{logger}->writeLogError("cannot write file '$filename': $!");
        exit(1);
    }

    print $file $data;
    close $file;
}

1;

__END__